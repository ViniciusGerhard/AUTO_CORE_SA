# Contas de demonstração

| Perfil | Nome | E-mail | Senha |
|---|---|---|---|
| Administrador | Admin AutoCore | admin@autocore.com | Admin@2026 |
| Mecânico | Carlos Mendes | carlos@autocore.com | Carlos@2026 |
| Mecânico | Rafael Souza | rafael@autocore.com | Rafael@2026 |
| Cliente | Vinicius Gerhard | vinicius@email.com | Vinicius@2026 |
| Cliente | Fernanda Lima | fernanda@email.com | Fernanda@2026 |
| Cliente | Ricardo Oliveira | ricardo@email.com | Ricardo@2026 |

- Todos entram pela mesma tela (`login.html`); o perfil define o painel.
- Conta que já tinha senha salva neste navegador continua com a senha antiga.
- Mecânico cadastrado (ou com senha redefinida) pelo admin troca a senha no primeiro acesso.
- Não publique este arquivo junto com o site.
- Demonstração local: o login não protege os dados. Não use senhas nem dados reais.
