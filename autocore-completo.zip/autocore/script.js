/*
 * AutoCore — script único. Cada seção é isolada; procure por "===== nome =====".
 * Seções, na ordem de dependência:
 *   seed
 *   domain/errors
 *   store
 *   domain/constants
 *   util
 *   domain/queries
 *   ui/html
 *   ui/icons
 *   ui/feedback
 *   context
 *   ui/components
 *   domain/validation
 *   auth
 *   pages/public
 *   domain/actions
 *   pages/order
 *   pages/client
 *   pages/workshop
 *   ui/shell
 *   main
 */
'use strict';

/* ===== seed ===== */
const M_seed = (() => {
/* Dados de demonstração — os mesmos da versão original. */
const seed = () => structuredClone(DATA);

const DATA = {
  version: 2,
  currentUserId: null,
  users: [
    {id:'u1',name:'Vinicius Gerhard',email:'vinicius@email.com',cpf:'123.456.789-00',phone:'(47) 99999-1234',role:'client',createdAt:'2026-01-15',
     salt:'7808cc987a436fce51ccf7ecda13e5b0',passwordHash:'307c9097408a02885b3bc6beb4303d17bafdae475970e2a56f3e96ac7adac140'},
    {id:'u2',name:'Carlos Mendes',email:'carlos@autocore.com',cpf:'987.654.321-00',phone:'(47) 98888-5678',role:'mechanic',createdAt:'2025-06-10',specialty:'Freios e suspensão',rating:4.9,
     salt:'84643ceef76337ae3fd8f1a9c296230d',passwordHash:'1138bdcfd92b2014dc1d011e6b4a77edb7fd04839a990094594b26e999cf9fe8'},
    {id:'u3',name:'Rafael Souza',email:'rafael@autocore.com',cpf:'456.789.123-00',phone:'(47) 98877-4321',role:'mechanic',createdAt:'2025-03-20',specialty:'Motor e diagnóstico',rating:4.8,
     salt:'373a8ac615b7211d19da6d3eb130a040',passwordHash:'be86a3440e804bdab0424d831dc6e1da4959fc7413491707ea03c76736886d3c'},
    {id:'u4',name:'Admin AutoCore',email:'admin@autocore.com',cpf:'111.222.333-44',phone:'(47) 99000-0000',role:'admin',createdAt:'2025-01-01',
     salt:'72b32aa1969f9e56976dc5078489874c',passwordHash:'d58dfeee8593ebf185345bcd88a0f403ce76c8d551f536379a9299bfe16c32bc'},
    {id:'u5',name:'Fernanda Lima',email:'fernanda@email.com',cpf:'222.333.444-55',phone:'(47) 99111-2233',role:'client',createdAt:'2026-02-20',
     salt:'8fb30e671ae84bd5c31ad5bf979a1ae6',passwordHash:'ffdaabe4747d6e452535e78a39ac6b3340f2c9843a398553c7703c587a61fe7b'},
    {id:'u6',name:'Ricardo Oliveira',email:'ricardo@email.com',cpf:'333.444.555-66',phone:'(47) 99222-3344',role:'client',createdAt:'2026-03-10',
     salt:'6ae02fefc6cb8ad31c0288701ca8a486',passwordHash:'82feb2fc32c925d64dd539aefa835f7fa086d8ff1a98bd61dce90a98a82d701d'},
  ],
  vehicles: [
    {id:'v1',clientId:'u1',plate:'ABC-1234',brand:'Volkswagen',model:'Jetta GLi',year:2026,mileage:52430,color:'Cinza Escuro'},
    {id:'v2',clientId:'u5',plate:'DEF-5678',brand:'Toyota',model:'Corolla XRS',year:2025,mileage:28100,color:'Branco'},
    {id:'v3',clientId:'u6',plate:'GHI-9012',brand:'Honda',model:'Civic EX',year:2024,mileage:41500,color:'Preto'},
  ],
  appointments: [
    {id:'a1',clientId:'u1',vehicleId:'v1',date:'2026-10-08',time:'14:00',problem:'O carro está fazendo um barulho estranho quando freio, especialmente em altas velocidades.',status:'confirmed',mechanicId:'u2',createdAt:'2026-10-05'},
    {id:'a2',clientId:'u5',vehicleId:'v2',date:'2026-10-09',time:'09:00',problem:'Troca de óleo e revisão geral.',status:'scheduled',createdAt:'2026-10-06'},
    {id:'a3',clientId:'u6',vehicleId:'v3',date:'2026-10-10',time:'10:30',problem:'Ar-condicionado não está gelando.',status:'scheduled',createdAt:'2026-10-06'},
  ],
  services: [
    {id:'s1',name:'Troca de pastilhas de freio',description:'Substituição das pastilhas dianteiras ou traseiras',price:250},
    {id:'s2',name:'Alinhamento',description:'Alinhamento e geometria completa',price:120},
    {id:'s3',name:'Balanceamento',description:'Balanceamento das 4 rodas',price:80},
    {id:'s4',name:'Troca de óleo',description:'Troca de óleo do motor com filtro',price:150},
    {id:'s5',name:'Revisão dos freios',description:'Revisão completa do sistema de freios',price:200},
    {id:'s6',name:'Troca de correia dentada',description:'Substituição da correia dentada e tensor',price:450},
    {id:'s7',name:'Revisão de suspensão',description:'Diagnóstico e revisão da suspensão',price:300},
    {id:'s8',name:'Higienização do ar-condicionado',description:'Limpeza e higienização do sistema de A/C',price:180},
  ],
  parts: [
    {id:'p1',name:'Pastilha de freio dianteira',code:'PFD-001',manufacturer:'Brembo',price:180,quantity:12,minStock:5,category:'Freios'},
    {id:'p2',name:'Pastilha de freio traseira',code:'PFT-001',manufacturer:'Brembo',price:140,quantity:8,minStock:5,category:'Freios'},
    {id:'p3',name:'Disco de freio dianteiro',code:'DFD-001',manufacturer:'Bosch',price:320,quantity:4,minStock:4,category:'Freios'},
    {id:'p4',name:'Filtro de óleo',code:'FO-001',manufacturer:'Mann',price:45,quantity:20,minStock:10,category:'Motor'},
    {id:'p5',name:'Óleo motor 5W-30 1L',code:'OM-001',manufacturer:'Castrol',price:38,quantity:30,minStock:15,category:'Motor'},
    {id:'p6',name:'Correia dentada',code:'CD-001',manufacturer:'Gates',price:180,quantity:0,minStock:3,category:'Motor'},
    {id:'p7',name:'Amortecedor dianteiro',code:'AD-001',manufacturer:'Monroe',price:480,quantity:6,minStock:2,category:'Suspensão'},
    {id:'p8',name:'Fluido de freio DOT 4',code:'FF-001',manufacturer:'Bosch',price:55,quantity:15,minStock:8,category:'Freios'},
  ],
  workOrders: [
    {id:'os1',number:'00125',clientId:'u1',vehicleId:'v1',mechanicId:'u2',appointmentId:'a1',reportedProblem:'O carro está fazendo um barulho estranho quando freio, especialmente em altas velocidades.',diagnosis:'Desgaste acentuado das pastilhas de freio dianteiras. Disco dianteiro com sulcos leves. Recomendo troca das pastilhas e alinhamento.',services:[{serviceId:'s1',name:'Troca de pastilhas de freio',price:250},{serviceId:'s2',name:'Alinhamento',price:120}],parts:[{partId:'p1',name:'Pastilha de freio dianteira',quantity:1,unitPrice:180}],laborCost:200,status:'in_execution',observations:'Aguardando aprovação do cliente para iniciar.',openedAt:'2026-10-08',estimatedCompletion:'2026-10-08'},
    {id:'os2',number:'00124',clientId:'u1',vehicleId:'v1',mechanicId:'u3',reportedProblem:'Troca de óleo periódica.',diagnosis:'Óleo do motor vencido. Filtro de óleo entupido.',services:[{serviceId:'s4',name:'Troca de óleo',price:150}],parts:[{partId:'p4',name:'Filtro de óleo',quantity:1,unitPrice:45},{partId:'p5',name:'Óleo motor 5W-30 1L',quantity:5,unitPrice:38}],laborCost:0,status:'delivered',observations:'',openedAt:'2026-06-12',completedAt:'2026-06-12'},
  ],
  quotes: [
    {id:'q1',osId:'os1',servicesTotal:370,partsTotal:180,laborCost:200,total:750,status:'approved',validUntil:'2026-10-15',createdAt:'2026-10-08',notes:'Prazo estimado: 1 dia útil.'},
    {id:'q2',osId:'os2',servicesTotal:150,partsTotal:235,laborCost:0,total:385,status:'approved',validUntil:'2026-06-15',createdAt:'2026-06-12'},
  ],
  payments: [{id:'pay1',osId:'os2',amount:385,method:'pix',status:'paid',date:'2026-06-12',receipt:'REC-2026-00098'}],
  notifications: [
    {id:'n1',userId:'u1',title:'Orçamento disponível',message:'Seu orçamento para a OS #00125 está pronto. Clique para aprovar ou recusar.',read:false,type:'info',createdAt:'2026-10-08T10:30:00',link:'/client/quotes'},
    {id:'n2',userId:'u1',title:'Orçamento aprovado',message:'Seu orçamento para a OS #00125 foi aprovado. O serviço irá começar em breve.',read:false,type:'success',createdAt:'2026-10-08T11:00:00',link:'/client/orders/os1'},
    {id:'n3',userId:'u1',title:'Veículo em manutenção',message:'Seu Jetta GLi 2026 está em manutenção. Acompanhe o progresso em tempo real.',read:true,type:'info',createdAt:'2026-10-08T11:30:00',link:'/client/orders/os1'},
    {id:'n4',userId:'u1',title:'Troca de óleo concluída',message:'A manutenção da OS #00124 foi finalizada. Seu veículo está pronto para retirada.',read:true,type:'success',createdAt:'2026-06-12T16:00:00',link:'/client/orders/os2'},
  ],
};
return { seed };
})();

/* ===== domain/errors ===== */
const M_domain_errors = (() => {
/** Erro de regra de negócio: a mensagem pode ser mostrada ao usuário. */
class DomainError extends Error {}
return { DomainError };
})();

/* ===== store ===== */
const M_store = (() => {
const { seed } = M_seed;
const { DomainError } = M_domain_errors;
/* Persistência no localStorage, com conversão dos dados da versão anterior. */

const KEY = 'autocore_v2';
const LEGACY_KEY = 'autocore_vanilla_v1';
const BACKUP_KEY = 'autocore_corrompido';
const LISTS = ['users','vehicles','appointments','services','parts','workOrders','quotes','payments','notifications'];
const NUMERIC = ['price','quantity','minStock','mileage','year','laborCost','total','amount','servicesTotal','partsTotal','unitPrice'];
const isObject = x => x !== null && typeof x === 'object' && !Array.isArray(x);

/** Valida e converte um estado salvo ou importado. Lança erro se não for confiável. */
function normalize(raw) {
  if (!isObject(raw) || !LISTS.some(k => Array.isArray(raw[k]))) throw new DomainError('Arquivo não contém dados do AutoCore.');
  const base = seed();
  const state = { version: 2, currentUserId: typeof raw.currentUserId === 'string' ? raw.currentUserId : null };
  const clean = item => {
    if (!isObject(item)) throw new DomainError('Registro inválido nos dados.');
    for (const [key, value] of Object.entries(item)) {
      if ((key === 'id' || key.endsWith('Id')) && value != null && !/^[\w-]*$/.test(String(value))) throw new DomainError('Identificador inválido nos dados.');
      if (NUMERIC.includes(key)) item[key] = Number(value) || 0;
    }
    return item;
  };
  for (const key of LISTS) {
    const list = raw[key] === undefined ? base[key] : raw[key];
    if (!Array.isArray(list)) throw new DomainError(`Lista inválida: ${key}.`);
    state[key] = structuredClone(list).map(clean);
  }
  for (const u of state.users) {
    if (!['client','mechanic','admin'].includes(u.role)) throw new DomainError('Perfil de usuário inválido.');
    for (const k of ['name','email','cpf','phone']) u[k] = String(u[k] ?? '');
    // Conta de exemplo salva antes das senhas: recebe a senha de exemplo (ver docs/contas-demo.md).
    const demo = base.users.find(d => d.id === u.id && d.email === u.email);
    if (demo && !u.passwordHash) Object.assign(u, { salt: demo.salt, passwordHash: demo.passwordHash });
  }
  for (const o of state.workOrders) {
    o.services = (Array.isArray(o.services) ? o.services : []).map(clean);
    o.parts = (Array.isArray(o.parts) ? o.parts : []).map(clean);
  }
  for (const n of state.notifications) if (!String(n.link ?? '').startsWith('/')) n.link = '';
  return state;
}

function load(storage) {
  let raw = null;
  try {
    raw = storage.getItem(KEY) ?? storage.getItem(LEGACY_KEY);
    return { state: raw ? normalize(JSON.parse(raw)) : seed(), warning: '' };
  } catch (err) {
    console.warn('Dados salvos ilegíveis.', err);
    try { if (raw) storage.setItem(BACKUP_KEY, raw); } catch { /* sem espaço: o original não é apagado aqui */ }
    return { state: seed(), warning: 'Não foi possível ler os dados salvos. Uma cópia foi guardada e os dados de exemplo foram carregados.' };
  }
}
function save(storage, state) {
  try { storage.setItem(KEY, JSON.stringify(state)); return true; }
  catch (err) { console.warn('Armazenamento indisponível.', err); return false; }
}
return { KEY, LEGACY_KEY, BACKUP_KEY, normalize, load, save };
})();

/* ===== domain/constants ===== */
const M_domain_constants = (() => {
const TIMES = ['08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00'];
const QUOTE_VALIDITY_DAYS = 7;
const BRANDS = ['Volkswagen','Toyota','Honda','Chevrolet','Ford','Hyundai','Fiat','Nissan','Renault','Jeep','BMW','Mercedes-Benz','Audi'];
const ROLES = { client: 'Cliente', mechanic: 'Mecânico', admin: 'Administrador' };

const TIMELINE = [
  ['waiting','Aguardando'], ['in_evaluation','Avaliação'], ['quote_pending','Orçamento'], ['quote_approved','Aprovado'],
  ['in_execution','Execução'], ['finished','Finalizada'], ['awaiting_payment','Pagamento'], ['paid','Pago'], ['delivered','Entregue'],
];
const ORDER_STATUS = {
  waiting: ['Aguardando','muted'], in_evaluation: ['Em avaliação','info'], quote_pending: ['Orçamento pendente','warning'],
  quote_approved: ['Orçamento aprovado','success'], quote_rejected: ['Orçamento recusado','danger'], in_execution: ['Em execução','accent'],
  finished: ['Finalizada','success'], awaiting_payment: ['Aguardando pagamento','warning'], paid: ['Pago','success'],
  delivered: ['Entregue','success'], cancelled: ['Cancelada','danger'],
};
const APPT_STATUS = {
  scheduled: ['Agendado','info'], confirmed: ['Confirmado','success'], in_progress: ['Em andamento','accent'],
  completed: ['Concluído','success'], cancelled: ['Cancelado','danger'],
};
const QUOTE_STATUS = { pending: ['Pendente','warning'], approved: ['Aprovado','success'], rejected: ['Recusado','danger'], expired: ['Expirado','muted'] };
const PAYMENT_STATUS = { pending: ['Pendente','warning'], paid: ['Pago','success'], refunded: ['Estornado','info'], failed: ['Falhou','danger'] };
const PAYMENT_METHODS = { pix: 'PIX', credit_card: 'Cartão de crédito', debit_card: 'Cartão de débito', cash: 'Dinheiro', bank_transfer: 'Transferência' };

const CANCELLABLE = ['waiting','in_evaluation','quote_pending','quote_approved','quote_rejected'];
const CLOSED = ['delivered','cancelled'];
const DONE = ['finished','awaiting_payment','paid','delivered'];
return { TIMES, QUOTE_VALIDITY_DAYS, BRANDS, ROLES, TIMELINE, ORDER_STATUS, APPT_STATUS, QUOTE_STATUS, PAYMENT_STATUS, PAYMENT_METHODS, CANCELLABLE, CLOSED, DONE };
})();

/* ===== util ===== */
const M_util = (() => {
const pad = n => String(n).padStart(2, '0');

/** Data local no formato AAAA-MM-DD (sem conversão para UTC). */
const isoDate = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (iso, days) => { const d = new Date(`${iso}T12:00:00`); d.setDate(d.getDate() + days); return isoDate(d); };
const money = n => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const km = n => `${Number(n || 0).toLocaleString('pt-BR')} km`;
const dateBR = v => (v ? new Date(`${v}T12:00:00`).toLocaleDateString('pt-BR') : '—');
const dateTimeBR = v => (v ? new Date(v).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '—');
const newId = prefix => `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
return { isoDate, addDays, money, km, dateBR, dateTimeBR, newId, plural };
})();

/* ===== domain/queries ===== */
const M_domain_queries = (() => {
const { DONE } = M_domain_constants;
const { isoDate } = M_util;
const byId = (list, id) => list.find(item => item.id === id);
const orderTotals = os => {
  const services = os.services.reduce((a, s) => a + Number(s.price || 0), 0);
  const parts = os.parts.reduce((a, p) => a + Number(p.quantity || 0) * Number(p.unitPrice || 0), 0);
  const labor = Number(os.laborCost || 0);
  return { services, parts, labor, total: services + parts + labor };
};
/** Orçamento vigente: o mais recente da OS. */
const quoteOf = (state, osId) => state.quotes.filter(q => q.osId === osId).at(-1);
const quoteState = (q, today = isoDate()) => (q.status === 'pending' && q.validUntil < today ? 'expired' : q.status);
const stockStatus = p => (p.quantity <= 0 ? 'out' : p.quantity <= p.minStock ? 'low' : 'available');
const usersByRole = (state, role) => state.users.filter(u => u.role === role);
/** Registros desativados continuam no histórico, mas não entram em novas escolhas. */
const isActive = item => item.active !== false;
const activeMechanics = state => usersByRole(state, 'mechanic').filter(isActive);

function slotTaken(state, date, time) {
  const booked = state.appointments.filter(a => a.date === date && a.time === time && a.status !== 'cancelled').length;
  return booked >= activeMechanics(state).length;
}
function slotAvailable(state, date, time, now = new Date()) {
  const today = isoDate(now);
  const clock = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  if (!date || date < today || (date === today && time <= clock)) return false;
  return !slotTaken(state, date, time);
}

function periodStart(period, now = new Date()) {
  const month = period === 'year' ? 0 : period === 'quarter' ? Math.floor(now.getMonth() / 3) * 3 : now.getMonth();
  return isoDate(new Date(now.getFullYear(), month, 1));
}
function monthlyRevenue(state, now = new Date(), months = 6) {
  return Array.from({ length: months }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (months - 1 - i), 1);
    const key = isoDate(d).slice(0, 7);
    const value = state.payments.filter(p => p.status === 'paid' && p.date.startsWith(key)).reduce((a, p) => a + p.amount, 0);
    const label = d.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
    return { key, label, value };
  });
}
function report(state, period, now = new Date()) {
  const from = periodStart(period, now);
  const to = isoDate(now);
  const inRange = d => Boolean(d) && d >= from && d <= to;
  const payments = state.payments.filter(p => p.status === 'paid' && inRange(p.date));
  const revenue = payments.reduce((a, p) => a + p.amount, 0);
  const counts = new Map();
  state.workOrders.filter(o => inRange(o.openedAt) && o.status !== 'cancelled')
    .forEach(o => o.services.forEach(s => counts.set(s.name, (counts.get(s.name) || 0) + 1)));
  return {
    revenue,
    ticket: payments.length ? revenue / payments.length : 0,
    finished: state.workOrders.filter(o => DONE.includes(o.status) && inRange(o.completedAt)).length,
    cancelled: state.workOrders.filter(o => o.status === 'cancelled' && inRange(o.cancelledAt || o.openedAt)).length,
    topServices: [...counts].sort((a, b) => b[1] - a[1]).slice(0, 5),
  };
}
return { byId, orderTotals, quoteOf, quoteState, stockStatus, usersByRole, isActive, activeMechanics, slotTaken, slotAvailable, periodStart, monthlyRevenue, report };
})();

/* ===== ui/html ===== */
const M_ui_html = (() => {
/* Template com escape automático: todo valor interpolado é tratado como texto, salvo outro html``. */
class Safe { constructor(s) { this.s = s; } toString() { return this.s; } }
const MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const render = value => {
  if (value instanceof Safe) return value.s;
  if (Array.isArray(value)) return value.map(render).join('');
  if (value === null || value === undefined || value === false) return '';
  return String(value).replace(/[&<>"']/g, c => MAP[c]);
};
const html = (strings, ...values) => new Safe(strings.reduce((out, s, i) => out + s + (i < values.length ? render(values[i]) : ''), ''));
/** Somente para marcação fixa do próprio código (ícones). */
const raw = s => new Safe(s);
return { html, raw };
})();

/* ===== ui/icons ===== */
const M_ui_icons = (() => {
const { raw } = M_ui_html;
const PATHS = {
  home: 'M3 11l9-8 9 8M5 10v10h14V10', car: 'M5 16h14M3 16v-4l2-5h14l2 5v4M6 16v3m12-3v3M3 12h18',
  calendar: 'M4 6h16v15H4zM4 10h16M8 3v5m8-5v5', clipboard: 'M8 4h8v4H8zM8 6H5v15h14V6h-3M8 13h8M8 17h5',
  money: 'M12 3v18M17 7c-1-2-9-3-9 1s9 3 9 7-8 3-10 1', clock: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l4 2',
  card: 'M3 6h18v12H3zM3 10h18', bell: 'M6 17V11a6 6 0 1112 0v6l2 2H4zM10 22h4',
  users: 'M9 11a4 4 0 100-8 4 4 0 000 8zM2 21c0-8 14-8 14 0M17 4a4 4 0 010 7M18 15c3 1 4 3 4 6',
  wrench: 'M15 4a5 5 0 00-5 7l-7 7 3 3 7-7a5 5 0 007-6l-4 3-3-3z', box: 'M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10',
  chart: 'M4 20V10m6 10V4m6 16v-7M3 20h18', tag: 'M3 3h8l10 10-8 8L3 11zM8 8h.01', menu: 'M4 6h16M4 12h16M4 18h16',
  sun: 'M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12l1 1M19 5l-1 1M6 18l-1 1',
  logout: 'M10 4H4v16h6M16 8l4 4-4 4M20 12H9', check: 'M4 12l5 5L20 6', x: 'M6 6l12 12M18 6L6 18',
  gear: 'M12 9a3 3 0 100 6 3 3 0 000-6zM12 1v4m0 14v4M4 4l3 3m10 10l3 3M1 12h4m14 0h4M4 20l3-3M17 7l3-3',
};
const icon = name => raw(`<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${PATHS[name] ?? PATHS.gear}"/></svg>`);
return { icon };
})();

/* ===== ui/feedback ===== */
const M_ui_feedback = (() => {
const { html } = M_ui_html;
const { icon } = M_ui_icons;
function toast(message, tone = 'success') {
  const region = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast toast-${tone}`;
  el.textContent = message;
  region.replaceChildren(el);
  setTimeout(() => el.remove(), tone === 'danger' ? 6000 : 3500);
}

const dialog = () => document.getElementById('dialog');
/** <dialog> nativo: foco preso, Esc fecha e o foco volta ao botão de origem. */
function openDialog(title, body) {
  const el = dialog();
  el.innerHTML = String(html`<header><h2 id="dialog-title">${title}</h2>
    <button type="button" class="btn btn-icon btn-ghost" data-action="close-dialog" aria-label="Fechar">${icon('x')}</button></header>
    <div class="dialog-body">${body}</div>`);
  el.showModal();
}
const closeDialog = () => { if (dialog().open) dialog().close(); };
const dialogActions = label => html`<div class="actions"><button type="button" class="btn btn-secondary" data-action="close-dialog">Cancelar</button><button class="btn">${label}</button></div>`;
return { toast, dialog, openDialog, closeDialog, dialogActions };
})();

/* ===== context ===== */
const M_context = (() => {
const { load, save } = M_store;
const { byId } = M_domain_queries;
const { DomainError } = M_domain_errors;
const { toast } = M_ui_feedback;
/* Estado compartilhado pelas páginas e registro de ações e formulários. */

const initial = load(localStorage);
const app = { state: initial.state, warning: initial.warning, render: () => {} };

const emptyView = () => ({
  register: { step: 1, draft: {} },
  appointment: { step: 'vehicle', vehicleId: '', problem: '', date: '', time: '' },
  clientSearch: '', partSearch: '', partFilter: 'all', orderFilter: 'all', reportPeriod: 'month',
  loginError: '', sidebarOpen: false,
});
const view = emptyView();
const resetView = () => Object.assign(view, emptyView());

const currentUser = () => {
  const user = byId(app.state.users, app.state.currentUserId);
  return user && user.active !== false ? user : null;
};
const home = role => `/${role}`;
const go = path => { if (location.hash === `#${path}`) app.render(); else location.hash = path; };

function persist() {
  if (!save(localStorage, app.state)) toast('Não foi possível salvar neste navegador.', 'danger');
}
/** Executa uma alteração, salva e redesenha. Erros de regra viram aviso. */
function commit(change, message) {
  try {
    const result = change(app.state, currentUser());
    persist(); app.render();
    if (message) toast(message);
    return { ok: true, result };
  } catch (err) {
    report(err);
    return { ok: false };
  }
}
function report(err) {
  if (err instanceof DomainError) toast(err.message, 'danger');
  else { console.error(err); toast('Algo deu errado. Recarregue a página e tente novamente.', 'danger'); }
}

const actions = {};
const forms = {};
return { app, emptyView, view, resetView, currentUser, home, go, persist, commit, report, actions, forms };
})();

/* ===== ui/components ===== */
const M_ui_components = (() => {
const { html } = M_ui_html;
const { icon } = M_ui_icons;
const { money } = M_util;
const { orderTotals } = M_domain_queries;
const brand = html`<a class="brand" href="index.html"><span class="brand-mark">${icon('gear')}</span><span>Auto<b>Core</b></span></a>`;
const badge = ([label, tone = 'muted'] = ['Indefinido']) => html`<span class="badge badge-${tone}">${label}</span>`;
const link = (href, label, cls = 'btn') => html`<a class="${cls}" href="#${href}">${label}</a>`;
const button = (label, action, { cls = 'btn', id = '', value = '', disabled = false, aria = '' } = {}) =>
  html`<button type="button" class="${cls}" data-action="${action}" data-id="${id}" data-value="${value}" ${disabled ? 'disabled' : ''} ${aria ? html`aria-label="${aria}"` : ''}>${label}</button>`;

const page = ({ title, subtitle = '', crumbs = [], actions = '', body }) => html`
  <header class="page-header">
    <div>${crumbs.length ? html`<p class="crumbs">${crumbs.join(' / ')}</p>` : ''}<h1 tabindex="-1">${title}</h1>${subtitle ? html`<p class="subtitle">${subtitle}</p>` : ''}</div>
    ${actions ? html`<div class="row wrap">${actions}</div>` : ''}
  </header>
  <div class="page-body stack">${body}</div>`;

const card = (title, body, extra = '') => html`<section class="card">${title ? html`<div class="card-head"><h2>${title}</h2>${extra}</div>` : ''}${body}</section>`;
const stats = items => html`<div class="stats">${items.map(([label, value, sub]) => html`<div class="stat"><span>${label}</span><strong>${value}</strong>${sub ? html`<small>${sub}</small>` : ''}</div>`)}</div>`;
const empty = (title, text, action = '') => html`<div class="card empty"><h3>${title}</h3><p>${text}</p>${action}</div>`;
const alert = (tone, content) => html`<div class="alert alert-${tone}">${content}</div>`;
const rows = items => html`<dl class="rows">${items.map(([k, v]) => html`<div><dt>${k}</dt><dd>${v}</dd></div>`)}</dl>`;

const table = (headers, lines, emptyText = 'Nenhum registro encontrado.') => lines.length
  ? html`<div class="card table-wrap" tabindex="0"><table><thead><tr>${headers.map(h => html`<th scope="col">${h}</th>`)}</tr></thead>
      <tbody>${lines.map(cells => html`<tr>${cells.map((c, i) => html`<td data-label="${headers[i]}">${c}</td>`)}</tr>`)}</tbody></table></div>`
  : html`<div class="card empty"><p>${emptyText}</p></div>`;

const field = (label, name, { type = 'text', value = '', placeholder = '', required = true, attrs = '' } = {}) => html`
  <label class="field"><span>${label}</span><input name="${name}" type="${type}" value="${value}" placeholder="${placeholder}" ${required ? 'required' : ''} ${attrs}></label>`;
const select = (label, name, options, selected = '', { required = true } = {}) => html`
  <label class="field"><span>${label}</span><select name="${name}" ${required ? 'required' : ''}>${options.map(([v, l]) => html`<option value="${v}" ${v === selected ? 'selected' : ''}>${l}</option>`)}</select></label>`;
const textarea = (label, name, value = '', { placeholder = '', required = false } = {}) => html`
  <label class="field"><span>${label}</span><textarea name="${name}" rows="4" placeholder="${placeholder}" ${required ? 'required' : ''}>${value}</textarea></label>`;
const filters = (action, current, options) => html`<div class="filters" role="group" aria-label="Filtros">${options.map(([v, l]) =>
  html`<button type="button" class="chip" data-action="${action}" data-value="${v}" aria-pressed="${String(current === v)}">${l}</button>`)}</div>`;

const chart = data => {
  const max = Math.max(...data.map(d => d.value), 1);
  return html`<ul class="chart" aria-label="Faturamento mensal">${data.map(d => html`
    <li title="${d.label}: ${money(d.value)}"><span class="chart-value">${d.value ? money(d.value).replace(/,\d\d$/, '') : '—'}</span>
    <span class="chart-track"><span class="chart-bar" style="height:${(d.value / max) * 100}%"></span></span><span>${d.label}</span></li>`)}</ul>`;
};

const orderItems = (os, { onRemove = false } = {}) => {
  const t = orderTotals(os);
  const remove = (kind, i, name) => (onRemove ? button(icon('x'), 'remove-item', { cls: 'btn btn-icon btn-ghost', id: os.id, value: `${kind}:${i}`, aria: `Remover ${name}` }) : '');
  return html`<ul class="items">
    ${os.services.map((s, i) => html`<li><span>${s.name}</span><strong>${money(s.price)}</strong>${remove('service', i, s.name)}</li>`)}
    ${os.parts.map((p, i) => html`<li><span>${p.name} × ${p.quantity}</span><strong>${money(p.quantity * p.unitPrice)}</strong>${remove('part', i, p.name)}</li>`)}
    ${t.labor ? html`<li><span>Mão de obra</span><strong>${money(t.labor)}</strong></li>` : ''}
    <li class="total"><span>Total</span><strong>${money(t.total)}</strong></li></ul>`;
};
return { brand, badge, link, button, page, card, stats, empty, alert, rows, table, field, select, textarea, filters, chart, orderItems };
})();

/* ===== domain/validation ===== */
const M_domain_validation = (() => {
const { DomainError } = M_domain_errors;
const digits = v => String(v ?? '').replace(/\D/g, '');

function formatCpf(value) {
  const d = digits(value);
  if (d.length !== 11 || /^(\d)\1+$/.test(d)) throw new DomainError('CPF inválido.');
  for (const len of [9, 10]) {
    let sum = 0;
    for (let i = 0; i < len; i++) sum += Number(d[i]) * (len + 1 - i);
    if (((sum * 10) % 11) % 10 !== Number(d[len])) throw new DomainError('CPF inválido: confira os números digitados.');
  }
  return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}
const plateKey = v => String(v ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function formatPlate(value) {
  const p = plateKey(value);
  if (/^[A-Z]{3}\d{4}$/.test(p)) return `${p.slice(0, 3)}-${p.slice(3)}`;
  if (/^[A-Z]{3}\d[A-Z]\d{2}$/.test(p)) return p;
  throw new DomainError('Informe uma placa válida (ABC-1234 ou ABC1D23).');
}
function required(value, label) {
  const v = String(value ?? '').trim();
  if (!v) throw new DomainError(`Preencha o campo ${label}.`);
  return v;
}
function email(value) {
  const v = String(value ?? '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new DomainError('Informe um e-mail válido.');
  return v;
}
function number(value, label, { min = 0, max = 1e9, integer = false } = {}) {
  const n = Number(value);
  if (String(value ?? '').trim() === '' || !Number.isFinite(n) || n < min || n > max || (integer && !Number.isInteger(n))) {
    throw new DomainError(`Valor inválido em ${label}.`);
  }
  return n;
}
return { formatCpf, plateKey, formatPlate, required, email, number };
})();

/* ===== auth ===== */
const M_auth = (() => {
const { DomainError } = M_domain_errors;
const v = M_domain_validation;
const { isoDate, newId } = M_util;
/*
 * Autenticação de DEMONSTRAÇÃO. A senha é guardada apenas como hash (PBKDF2), mas os dados
 * ficam no navegador e podem ser alterados por quem tem acesso a ele. Não é segurança real.
 */

const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
async function hash(password, salt) {
  if (!globalThis.crypto?.subtle) throw new DomainError('Abra o sistema por http://localhost ou https para usar senha.');
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: 100_000 }, key, 256));
}
function checkNewPassword(password, confirm) {
  if (String(password ?? '').length < 6) throw new DomainError('A senha deve ter no mínimo 6 caracteres.');
  if (password !== confirm) throw new DomainError('As senhas não conferem.');
}
async function setPassword(user, password) {
  const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
  const passwordHash = await hash(password, salt);
  Object.assign(user, { salt, passwordHash });
}
/** Troca a senha provisória definida pelo administrador. */
async function replaceProvisionalPassword(user, password, confirm) {
  if (!user?.mustChangePassword) throw new DomainError('Não há senha provisória para trocar.');
  checkNewPassword(password, confirm);
  if (await verify(user, password)) throw new DomainError('A nova senha deve ser diferente da provisória.');
  await setPassword(user, password);
  delete user.mustChangePassword;
}
const findByEmail = (state, value) => state.users.find(u => u.email.toLowerCase() === String(value ?? '').trim().toLowerCase());
async function verify(user, password) {
  return Boolean(user?.passwordHash) && (await hash(password, user.salt)) === user.passwordHash;
}
function validatePerson(state, data, id, keepCpf) {
  const person = {
    name: v.required(data.name, 'Nome'),
    // Cadastro antigo pode ter CPF fictício: um CPF que não mudou não é revalidado.
    cpf: keepCpf && data.cpf === keepCpf ? keepCpf : v.formatCpf(data.cpf),
    phone: v.required(data.phone, 'Telefone'), email: v.email(data.email),
  };
  const others = state.users.filter(u => u.id !== id);
  if (others.some(u => u.email.toLowerCase() === person.email)) throw new DomainError('Este e-mail já está cadastrado.');
  if (others.some(u => u.cpf === person.cpf)) throw new DomainError('Este CPF já está cadastrado.');
  return person;
}
async function registerClient(state, draft, password) {
  const user = { id: newId('u'), ...validatePerson(state, draft), role: 'client', createdAt: isoDate() };
  await setPassword(user, password);
  state.users.push(user);
  return user;
}
async function saveMechanic(state, actor, data, id) {
  if (actor?.role !== 'admin') throw new DomainError('Seu perfil não permite esta ação.');
  const old = id ? state.users.find(u => u.id === id && u.role === 'mechanic') : null;
  if (id && !old) throw new DomainError('Mecânico não encontrado.');
  const person = validatePerson(state, data, id, old?.cpf);
  const user = old ? { ...old } : { id: newId('u'), role: 'mechanic', createdAt: isoDate(), rating: null };
  Object.assign(user, person, { specialty: String(data.specialty ?? '').trim() });
  if (!old || data.password) {
    checkNewPassword(data.password, data.password);
    await setPassword(user, data.password);
    user.mustChangePassword = true;
  }
  if (old) Object.assign(old, user); else state.users.push(user);
}
return { replaceProvisionalPassword, checkNewPassword, setPassword, findByEmail, verify, validatePerson, registerClient, saveMechanic };
})();

/* ===== pages/public ===== */
const M_pages_public = (() => {
const { html } = M_ui_html;
const { icon } = M_ui_icons;
const { brand, alert, field, button } = M_ui_components;
const { app, view, actions, forms, go, home, persist, report, resetView } = M_context;
const { findByEmail, verify, setPassword, checkNewPassword, replaceProvisionalPassword, validatePerson, registerClient } = M_auth;
const { byId } = M_domain_queries;
const { normalize, KEY } = M_store;
const { toast, openDialog, closeDialog, dialogActions } = M_ui_feedback;
const { isoDate } = M_util;
const themeButton = () => button(icon('sun'), 'toggle-theme', { cls: 'btn btn-icon btn-ghost', aria: 'Alternar tema claro e escuro' });

const authLayout = content => html`<div class="auth">
  <aside>${brand}<div><h2>Sua oficina, na palma da mão.</h2><ul><li>Orçamento antes de qualquer serviço</li><li>Acompanhamento de cada etapa</li><li>Histórico completo do veículo</li></ul></div><small>© 2026 AutoCore</small></aside>
  <main><div class="auth-card"><div class="row-between">${brand}${themeButton()}</div>${content}
  ${alert('info', 'Demonstração: os dados ficam somente neste navegador. Não use informações ou senhas reais.')}</div></main></div>`;

const loginPage = () => authLayout(html`
  <h1 tabindex="-1">Bem-vindo de volta</h1><p class="muted">Entre com sua conta para continuar.</p>
  <form data-form="login" class="stack">${field('E-mail', 'email', { type: 'email', placeholder: 'seu@email.com', attrs: 'autocomplete=username' })}
    ${field('Senha', 'password', { type: 'password', attrs: 'autocomplete=current-password' })}
    ${view.loginError ? html`<div class="alert alert-danger" role="alert">${view.loginError}</div>` : ''}<button class="btn">Entrar</button></form>
  <p>Não tem conta? <a href="#/register">Criar conta grátis</a></p>
  <p class="row wrap"><a href="index.html">← Voltar ao início</a>${button('Exportar ou importar dados', 'open-data', { cls: 'link' })}</p>`);

const registerPage = () => {
  const { step, draft } = view.register;
  return authLayout(html`<h1 tabindex="-1">Criar conta</h1><p class="muted">Etapa ${step} de 2: ${step === 1 ? 'seus dados pessoais' : 'defina sua senha'}.</p>
    <form data-form="register" class="stack">${step === 1 ? html`
      ${field('Nome completo', 'name', { value: draft.name ?? '', attrs: 'autocomplete=name' })}
      ${field('CPF', 'cpf', { value: draft.cpf ?? '', placeholder: '000.000.000-00', attrs: 'inputmode=numeric' })}
      ${field('Telefone', 'phone', { type: 'tel', value: draft.phone ?? '', placeholder: '(47) 99999-0000' })}
      ${field('E-mail', 'email', { type: 'email', value: draft.email ?? '' })}<button class="btn">Continuar</button>` : html`
      ${field('Senha', 'password', { type: 'password', placeholder: 'Mínimo 6 caracteres', attrs: 'autocomplete=new-password' })}
      ${field('Confirmar senha', 'confirm', { type: 'password', attrs: 'autocomplete=new-password' })}
      <div class="actions">${button('← Voltar', 'register-back', { cls: 'btn btn-secondary' })}<button class="btn">Criar conta</button></div>`}</form>
    <p>Já tem conta? <a href="#/login">Entrar</a></p>`);
};

const changePasswordPage = user => authLayout(html`
  <h1 tabindex="-1">Crie sua senha</h1><p class="muted">${user.name}, sua senha atual é provisória. Troque-a para continuar.</p>
  <form data-form="change-password" class="stack">
    ${field('Nova senha', 'password', { type: 'password', placeholder: 'Mínimo 6 caracteres', attrs: 'autocomplete=new-password' })}
    ${field('Confirmar senha', 'confirm', { type: 'password', attrs: 'autocomplete=new-password' })}
    <button class="btn">Salvar e entrar</button></form>
  <p>${button('Sair', 'logout', { cls: 'link' })}</p>`);

function enter(user) {
  resetView(); app.state.currentUserId = user.id; persist(); go(home(user.role));
}
Object.assign(actions, {
  'register-back': () => { view.register.step = 1; app.render(); },
  'open-data': () => openDialog('Exportar ou importar dados', html`<div class="stack">
    <p class="muted">A exportação gera um arquivo com todos os dados deste navegador. A importação substitui os dados atuais.</p>
    ${button('Exportar dados', 'export-data', { cls: 'btn btn-secondary' })}
    <form data-form="import" class="stack"><label class="field"><span>Arquivo .json</span><input type="file" name="file" accept=".json,application/json" required></label>${dialogActions('Importar e substituir')}</form></div>`),
  'export-data': () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(app.state, null, 2)], { type: 'application/json' }));
    Object.assign(document.createElement('a'), { href: url, download: `autocore-${isoDate()}.json` }).click();
    URL.revokeObjectURL(url);
  },
});

Object.assign(forms, {
  async login(values) {
    const found = findByEmail(app.state, values.email);
    const user = found?.active === false ? null : found;
    try {
      if (user && !user.passwordHash) {
        return openDialog('Defina sua senha', html`<form data-form="first-password" data-id="${user.id}" class="stack">
          <p class="muted">Esta conta foi criada antes de o sistema usar senha. Escolha uma agora.</p>
          ${field('Nova senha', 'password', { type: 'password' })}${field('Confirmar senha', 'confirm', { type: 'password' })}${dialogActions('Salvar e entrar')}</form>`);
      }
      if (user && await verify(user, values.password)) return enter(user);
      view.loginError = 'E-mail ou senha incorretos. Confira os dados e tente novamente.';
      app.render();
    } catch (err) { report(err); }
  },
  async 'first-password'(values, form) {
    const user = byId(app.state.users, form.dataset.id);
    if (!user || user.passwordHash) return;
    try { checkNewPassword(values.password, values.confirm); await setPassword(user, values.password); closeDialog(); enter(user); }
    catch (err) { report(err); }
  },
  async 'change-password'(values) {
    const user = byId(app.state.users, app.state.currentUserId);
    try { await replaceProvisionalPassword(user, values.password, values.confirm); enter(user); toast('Senha alterada.'); }
    catch (err) { report(err); }
  },
  async register(values) {
    const reg = view.register;
    try {
      if (reg.step === 1) { reg.draft = validatePerson(app.state, values); reg.step = 2; return app.render(); }
      checkNewPassword(values.password, values.confirm);
      const user = await registerClient(app.state, reg.draft, values.password);
      enter(user); toast('Conta criada com sucesso!');
    } catch (err) { report(err); }
  },
  async import(values) {
    try {
      const data = normalize(JSON.parse(await values.file.text()));
      data.currentUserId = null;
      localStorage.setItem(KEY, JSON.stringify(data));
      app.state = data; closeDialog(); resetView(); app.render(); toast('Dados importados.');
    } catch (err) {
      if (err instanceof SyntaxError) toast('O arquivo não é um JSON válido.', 'danger'); else report(err);
    }
  },
});
return { themeButton, loginPage, registerPage, changePasswordPage };
})();

/* ===== domain/actions ===== */
const M_domain_actions = (() => {
const { TIMES, BRANDS, QUOTE_VALIDITY_DAYS, CANCELLABLE, PAYMENT_METHODS, ORDER_STATUS } = M_domain_constants;
const { DomainError } = M_domain_errors;
const { byId, orderTotals, quoteOf, quoteState, slotAvailable, isActive } = M_domain_queries;
const v = M_domain_validation;
const { isoDate, addDays, newId } = M_util;
/*
 * Todas as alterações de dados passam por aqui. Cada função valida quem está agindo
 * e a situação atual antes de mudar qualquer coisa (valida tudo, depois grava).
 */

function allow(actor, ...roles) {
  if (!actor || !roles.includes(actor.role)) throw new DomainError('Seu perfil não permite esta ação.');
  if (actor.mustChangePassword) throw new DomainError('Troque a senha provisória antes de continuar.');
}
function find(list, id, label) {
  const item = byId(list, id);
  if (!item) throw new DomainError(`${label} não encontrado(a).`);
  return item;
}
/** OS que o ator pode operar: admin todas; mecânico as suas; cliente as próprias. */
function ownOrder(state, actor, osId) {
  const os = find(state.workOrders, osId, 'OS');
  if (actor.role === 'mechanic' && os.mechanicId !== actor.id) throw new DomainError('Esta OS está atribuída a outro mecânico.');
  if (actor.role === 'client' && os.clientId !== actor.id) throw new DomainError('Esta OS não é sua.');
  return os;
}
function expect(os, ...statuses) {
  if (!statuses.includes(os.status)) throw new DomainError(`Ação indisponível com a OS "${ORDER_STATUS[os.status]?.[0] ?? os.status}".`);
}
function notify(state, userId, title, message, type, link) {
  state.notifications.unshift({ id: newId('n'), userId, title, message, type, link, read: false, createdAt: new Date().toISOString() });
}
function setStatus(state, os, status, type = 'info') {
  os.status = status;
  notify(state, os.clientId, 'Status da OS atualizado', `A OS #${os.number} agora está: ${ORDER_STATUS[status][0]}.`, type, `/client/orders/${os.id}`);
}
const linkedAppointment = (state, os) => byId(state.appointments, os.appointmentId);

/* ---------- Cliente ---------- */
function saveVehicle(state, actor, data, vehicleId) {
  allow(actor, 'client');
  const old = vehicleId ? find(state.vehicles, vehicleId, 'Veículo') : null;
  if (old && old.clientId !== actor.id) throw new DomainError('Este veículo não é seu.');
  const plate = v.formatPlate(data.plate);
  if (state.vehicles.some(x => x.id !== vehicleId && v.plateKey(x.plate) === v.plateKey(plate))) throw new DomainError('Esta placa já está cadastrada.');
  const brand = v.required(data.brand, 'Marca');
  if (!BRANDS.includes(brand) && brand !== old?.brand) throw new DomainError('Selecione uma marca da lista.');
  const fields = {
    plate, brand, model: v.required(data.model, 'Modelo'),
    year: v.number(data.year, 'Ano', { min: 1980, max: new Date().getFullYear() + 1, integer: true }),
    mileage: v.number(data.mileage, 'Quilometragem', { max: 5e6 }),
    color: String(data.color ?? '').trim(),
  };
  if (old) return Object.assign(old, fields);
  const vehicle = { id: newId('v'), clientId: actor.id, ...fields };
  state.vehicles.push(vehicle);
  return vehicle;
}

function createAppointment(state, actor, { vehicleId, problem, date, time }, now = new Date()) {
  allow(actor, 'client');
  if (find(state.vehicles, vehicleId, 'Veículo').clientId !== actor.id) throw new DomainError('Este veículo não é seu.');
  const text = String(problem ?? '').trim();
  if (text.length < 10) throw new DomainError('Descreva o problema com pelo menos 10 caracteres.');
  if (!TIMES.includes(time) || !slotAvailable(state, date, time, now)) throw new DomainError('Este horário não está mais disponível. Escolha outro.');
  const appointment = { id: newId('a'), clientId: actor.id, vehicleId, date, time, problem: text, status: 'scheduled', createdAt: isoDate(now) };
  state.appointments.push(appointment);
  return appointment;
}

function decideQuote(state, actor, quoteId, approve, today = isoDate()) {
  allow(actor, 'client');
  const quote = find(state.quotes, quoteId, 'Orçamento');
  const os = ownOrder(state, actor, quote.osId);
  expect(os, 'quote_pending');
  if (quoteState(quote, today) !== 'pending') throw new DomainError('Este orçamento não está mais disponível. Peça um novo à oficina.');
  quote.status = approve ? 'approved' : 'rejected';
  os.status = approve ? 'quote_approved' : 'quote_rejected';
  const verb = approve ? 'aprovou' : 'recusou';
  notify(state, actor.id, `Orçamento ${approve ? 'aprovado' : 'recusado'}`, `Você ${verb} o orçamento da OS #${os.number}.`, approve ? 'success' : 'warning', `/client/orders/${os.id}`);
  if (os.mechanicId) notify(state, os.mechanicId, `Orçamento ${approve ? 'aprovado' : 'recusado'}`, `O cliente ${verb} o orçamento da OS #${os.number}.`, approve ? 'success' : 'warning', `/mechanic/orders/${os.id}`);
}

function markRead(state, actor, notificationId) {
  const n = state.notifications.find(x => x.id === notificationId && x.userId === actor?.id);
  if (!n || n.read) return false;
  n.read = true;
  return true;
}

const canCancelAppointment = (state, appt) =>
  ['scheduled', 'confirmed'].includes(appt.status) && !state.workOrders.some(o => o.appointmentId === appt.id);

function cancelAppointment(state, actor, appointmentId) {
  allow(actor, 'client', 'admin');
  const appt = find(state.appointments, appointmentId, 'Agendamento');
  if (actor.role === 'client' && appt.clientId !== actor.id) throw new DomainError('Este agendamento não é seu.');
  if (!canCancelAppointment(state, appt)) throw new DomainError('Este agendamento já virou OS ou foi encerrado.');
  appt.status = 'cancelled';
  const when = `${appt.date.split('-').reverse().join('/')} às ${appt.time}`;
  if (actor.role === 'admin') notify(state, appt.clientId, 'Agendamento cancelado', `A oficina cancelou o agendamento de ${when}.`, 'warning', '/client/appointments');
  if (appt.mechanicId) notify(state, appt.mechanicId, 'Agendamento cancelado', `O atendimento de ${when} foi cancelado.`, 'warning', '/mechanic');
}

/* ---------- Oficina ---------- */
function assignMechanic(state, actor, appointmentId, mechanicId) {
  allow(actor, 'admin');
  const appt = find(state.appointments, appointmentId, 'Agendamento');
  const mechanic = find(state.users, mechanicId, 'Mecânico');
  if (mechanic.role !== 'mechanic' || !isActive(mechanic)) throw new DomainError('Selecione um mecânico.');
  if (!['scheduled', 'confirmed'].includes(appt.status) || state.workOrders.some(o => o.appointmentId === appt.id)) {
    throw new DomainError('Este agendamento já foi iniciado ou encerrado.');
  }
  const clash = state.appointments.some(a => a.id !== appt.id && a.mechanicId === mechanicId && a.date === appt.date && a.time === appt.time && !['cancelled', 'completed'].includes(a.status));
  if (clash) throw new DomainError(`${mechanic.name} já tem atendimento neste horário.`);
  appt.mechanicId = mechanicId;
  appt.status = 'confirmed';
}

function openOrder(state, actor, appointmentId) {
  allow(actor, 'admin', 'mechanic');
  const appt = find(state.appointments, appointmentId, 'Agendamento');
  if (!appt.mechanicId || !isActive(find(state.users, appt.mechanicId, 'Mecânico'))) throw new DomainError('Atribua um mecânico antes de abrir a OS.');
  if (actor.role === 'mechanic' && appt.mechanicId !== actor.id) throw new DomainError('Agendamento de outro mecânico.');
  if (['cancelled', 'completed'].includes(appt.status)) throw new DomainError('Este agendamento já foi encerrado.');
  if (state.workOrders.some(o => o.appointmentId === appt.id)) throw new DomainError('Este agendamento já tem uma OS.');
  const last = state.workOrders.reduce((max, o) => Math.max(max, Number.parseInt(o.number, 10) || 0), 0);
  const os = {
    id: newId('os'), number: String(last + 1).padStart(5, '0'), clientId: appt.clientId, vehicleId: appt.vehicleId,
    mechanicId: appt.mechanicId, appointmentId: appt.id, reportedProblem: appt.problem, diagnosis: '',
    services: [], parts: [], laborCost: 0, status: 'waiting', observations: '', openedAt: isoDate(),
  };
  state.workOrders.unshift(os);
  appt.status = 'in_progress';
  notify(state, os.clientId, 'OS aberta', `A OS #${os.number} foi aberta para o seu veículo.`, 'info', `/client/orders/${os.id}`);
  return os;
}

function startEvaluation(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, 'waiting');
  setStatus(state, os, 'in_evaluation');
}

/** Edição de diagnóstico e itens: somente durante a avaliação. */
function editable(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, 'in_evaluation');
  return os;
}
function saveDiagnosis(state, actor, osId, data) {
  const os = editable(state, actor, osId);
  const laborCost = v.number(data.laborCost || 0, 'Mão de obra');
  if (data.estimatedCompletion && data.estimatedCompletion < os.openedAt) throw new DomainError('A previsão não pode ser anterior à abertura.');
  Object.assign(os, {
    diagnosis: String(data.diagnosis ?? '').trim(), laborCost,
    estimatedCompletion: data.estimatedCompletion || '', observations: String(data.observations ?? '').trim(),
  });
}
function addService(state, actor, osId, serviceId) {
  const os = editable(state, actor, osId);
  const s = find(state.services, serviceId, 'Serviço');
  if (!isActive(s)) throw new DomainError('Este serviço está desativado.');
  os.services.push({ serviceId: s.id, name: s.name, price: s.price });
}
function addPart(state, actor, osId, partId, quantity) {
  const os = editable(state, actor, osId);
  const part = find(state.parts, partId, 'Peça');
  if (!isActive(part)) throw new DomainError('Esta peça está desativada.');
  const qty = v.number(quantity, 'Quantidade', { min: 1, max: 999, integer: true });
  const existing = os.parts.find(p => p.partId === part.id);
  if (existing) existing.quantity += qty;
  else os.parts.push({ partId: part.id, name: part.name, quantity: qty, unitPrice: part.price });
}
function removeItem(state, actor, osId, kind, index) {
  const os = editable(state, actor, osId);
  const list = kind === 'service' ? os.services : os.parts;
  if (!list[index]) throw new DomainError('Item não encontrado.');
  list.splice(index, 1);
}

function sendQuote(state, actor, osId, today = isoDate()) {
  const os = editable(state, actor, osId);
  if (!os.diagnosis) throw new DomainError('Salve o diagnóstico antes de enviar o orçamento.');
  const t = orderTotals(os);
  if (t.total <= 0) throw new DomainError('Inclua serviços, peças ou mão de obra.');
  state.quotes.push({
    id: newId('q'), osId: os.id, servicesTotal: t.services, partsTotal: t.parts, laborCost: t.labor, total: t.total,
    status: 'pending', createdAt: today, validUntil: addDays(today, QUOTE_VALIDITY_DAYS), notes: os.observations,
  });
  os.status = 'quote_pending';
  notify(state, os.clientId, 'Orçamento disponível', `O orçamento da OS #${os.number} está pronto para sua aprovação.`, 'info', `/client/orders/${os.id}`);
}

/** Sem orçamento válido (expirado ou inexistente em dados antigos), a OS volta à avaliação. */
function canReopen(state, os, today = isoDate()) {
  const q = quoteOf(state, os.id);
  if (os.status === 'quote_pending') return !q || quoteState(q, today) !== 'pending';
  return os.status === 'quote_approved' && q?.status !== 'approved';
}
function reopenEvaluation(state, actor, osId, today = isoDate()) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  if (!canReopen(state, os, today)) throw new DomainError('Esta OS tem um orçamento válido e não pode ser reaberta.');
  const q = quoteOf(state, os.id);
  if (q?.status === 'pending') q.status = 'expired';
  setStatus(state, os, 'in_evaluation');
}

function startExecution(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, 'quote_approved');
  if (quoteOf(state, os.id)?.status !== 'approved') throw new DomainError('O serviço só pode começar após a aprovação do cliente.');
  const needed = new Map();
  os.parts.forEach(p => needed.set(p.partId, (needed.get(p.partId) || 0) + p.quantity));
  for (const [partId, qty] of needed) {
    const part = find(state.parts, partId, 'Peça');
    if (part.quantity < qty) throw new DomainError(`Estoque insuficiente de ${part.name}: há ${part.quantity}, a OS usa ${qty}.`);
  }
  for (const [partId, qty] of needed) byId(state.parts, partId).quantity -= qty;
  setStatus(state, os, 'in_execution');
}

function finishOrder(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, 'in_execution');
  os.completedAt = isoDate();
  const appt = linkedAppointment(state, os);
  if (appt) appt.status = 'completed';
  setStatus(state, os, 'finished', 'success');
}
function requestPayment(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, 'finished');
  setStatus(state, os, 'awaiting_payment', 'warning');
}
function registerPayment(state, actor, osId, method) {
  allow(actor, 'admin');
  const os = ownOrder(state, actor, osId);
  expect(os, 'awaiting_payment');
  if (!Object.hasOwn(PAYMENT_METHODS, method)) throw new DomainError('Selecione a forma de pagamento.');
  if (state.payments.some(p => p.osId === os.id && p.status === 'paid')) throw new DomainError('Esta OS já foi paga.');
  const year = new Date().getFullYear();
  const seq = state.payments.reduce((max, p) => Math.max(max, Number(p.receipt?.split('-')[2]) || 0), 0) + 1;
  state.payments.push({ id: newId('pay'), osId: os.id, amount: orderTotals(os).total, method, status: 'paid', date: isoDate(), receipt: `REC-${year}-${String(seq).padStart(5, '0')}` });
  setStatus(state, os, 'paid', 'success');
}
function deliverOrder(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, 'paid');
  setStatus(state, os, 'delivered', 'success');
}
function cancelOrder(state, actor, osId) {
  allow(actor, 'admin', 'mechanic');
  const os = ownOrder(state, actor, osId);
  expect(os, ...CANCELLABLE);
  os.cancelledAt = isoDate();
  const q = quoteOf(state, os.id);
  if (q?.status === 'pending') q.status = 'expired';
  const appt = linkedAppointment(state, os);
  if (appt) appt.status = 'cancelled';
  setStatus(state, os, 'cancelled', 'error');
}

/* ---------- Cadastros (admin) ---------- */
function upsert(list, id, prefix, label, fields) {
  if (id) return Object.assign(find(list, id, label), fields);
  const item = { id: newId(prefix), ...fields };
  list.push(item);
  return item;
}
function saveService(state, actor, data, id) {
  allow(actor, 'admin');
  return upsert(state.services, id, 's', 'Serviço', {
    name: v.required(data.name, 'Nome'), description: String(data.description ?? '').trim(), price: v.number(data.price, 'Preço'),
  });
}
function savePart(state, actor, data, id) {
  allow(actor, 'admin');
  const code = v.required(data.code, 'Código').toUpperCase();
  if (state.parts.some(p => p.id !== id && p.code.toUpperCase() === code)) throw new DomainError('Já existe uma peça com este código.');
  return upsert(state.parts, id, 'p', 'Peça', {
    code, name: v.required(data.name, 'Nome'), manufacturer: v.required(data.manufacturer, 'Fabricante'),
    category: v.required(data.category, 'Categoria'), price: v.number(data.price, 'Preço'),
    quantity: v.number(data.quantity, 'Quantidade', { integer: true }), minStock: v.number(data.minStock, 'Estoque mínimo', { integer: true }),
  });
}
function adjustStock(state, actor, partId, data) {
  allow(actor, 'admin');
  const part = find(state.parts, partId, 'Peça');
  const quantity = v.number(data.quantity, 'Quantidade', { integer: true });
  const minStock = v.number(data.minStock, 'Estoque mínimo', { integer: true });
  Object.assign(part, { quantity, minStock });
}

const COLLECTIONS = { service: 'services', part: 'parts', mechanic: 'users' };
function setActive(state, actor, kind, id, active) {
  allow(actor, 'admin');
  const item = find(state[COLLECTIONS[kind]] ?? [], id, 'Cadastro');
  if (kind === 'mechanic') {
    if (item.role !== 'mechanic') throw new DomainError('Cadastro inválido.');
    if (!active) {
      const open = state.workOrders.filter(o => o.mechanicId === id && !['delivered', 'cancelled'].includes(o.status)).length;
      if (open) throw new DomainError(`${item.name} tem ${open} OS em aberto. Conclua ou cancele antes de desativar.`);
      // Agendamentos ainda sem OS voltam para a fila de atribuição.
      state.appointments.filter(a => a.mechanicId === id && canCancelAppointment(state, a))
        .forEach(a => { delete a.mechanicId; a.status = 'scheduled'; });
    }
  }
  item.active = active;
}
return { saveVehicle, createAppointment, decideQuote, markRead, canCancelAppointment, cancelAppointment, assignMechanic, openOrder, startEvaluation, saveDiagnosis, addService, addPart, removeItem, sendQuote, canReopen, reopenEvaluation, startExecution, finishOrder, requestPayment, registerPayment, deliverOrder, cancelOrder, saveService, savePart, adjustStock, setActive };
})();

/* ===== pages/order ===== */
const M_pages_order = (() => {
const { html } = M_ui_html;
const { page, card, rows, alert, badge, button, link, orderItems, empty, field, select, textarea } = M_ui_components;
const { app, actions, forms, commit } = M_context;
const act = M_domain_actions;
const { TIMELINE, ORDER_STATUS, QUOTE_STATUS, PAYMENT_METHODS, CANCELLABLE, ROLES } = M_domain_constants;
const { byId, quoteOf, quoteState, orderTotals } = M_domain_queries;
const { openDialog, closeDialog, dialogActions } = M_ui_feedback;
const { dateBR, money, km } = M_util;
/* Detalhe da OS, compartilhado pelos três perfis. */

const timeline = status => {
  if (['cancelled', 'quote_rejected'].includes(status)) return alert('danger', status === 'cancelled' ? 'OS cancelada.' : 'Orçamento recusado: esta OS não avança para execução.');
  const current = TIMELINE.findIndex(([k]) => k === status);
  return html`<ol class="timeline">${TIMELINE.map(([, label], i) => html`<li class="${i < current ? 'done' : i === current ? 'current' : ''}" ${i === current ? 'aria-current=step' : ''}><span>${i < current ? '✓' : i + 1}</span>${label}</li>`)}</ol>`;
};

const quoteButtons = (q, small = '') => html`<div class="actions">
  ${button('Recusar orçamento', 'reject-quote', { cls: `btn btn-danger ${small}`, id: q.id })}
  ${button('Aprovar orçamento', 'approve-quote', { cls: `btn btn-accent ${small}`, id: q.id })}</div>`;

function workshopPanel(os, user) {
  const s = app.state;
  const q = quoteOf(s, os.id);
  const next = {
    waiting: ['Iniciar avaliação', 'start-evaluation'], quote_approved: ['Iniciar execução', 'start-execution'],
    in_execution: ['Finalizar serviço', 'finish-order'], finished: ['Solicitar pagamento', 'request-payment'], paid: ['Marcar como entregue', 'deliver-order'],
  }[os.status];
  const reopen = act.canReopen(s, os);
  const blocked = reopen && os.status === 'quote_approved';
  const hint = {
    quote_pending: reopen ? 'Não há orçamento válido. Reabra a avaliação para enviar outro.' : 'Aguardando a decisão do cliente.',
    awaiting_payment: user.role === 'admin' ? '' : 'Aguardando o administrador registrar o pagamento.',
    in_evaluation: 'Preencha o diagnóstico e os itens abaixo e envie o orçamento.',
  }[os.status];
  const buttons = [
    next && !blocked ? button(next[0], next[1], { id: os.id }) : '',
    reopen ? button('Reabrir avaliação', 'reopen', { id: os.id }) : '',
    os.status === 'awaiting_payment' && user.role === 'admin' ? button('Registrar pagamento', 'open-payment', { id: os.id }) : '',
    CANCELLABLE.includes(os.status) ? button('Cancelar OS', 'open-cancel', { cls: 'btn btn-danger', id: os.id }) : '',
  ].filter(String);
  const evaluation = os.status !== 'in_evaluation' ? '' : html`
    ${card('Diagnóstico', html`<form data-form="diagnosis" data-id="${os.id}" class="stack">
      ${textarea('Diagnóstico técnico', 'diagnosis', os.diagnosis, { required: true })}
      <div class="grid grid-2">${field('Mão de obra (R$)', 'laborCost', { type: 'number', value: os.laborCost, required: false, attrs: 'min=0 step=0.01' })}
      ${field('Previsão de conclusão', 'estimatedCompletion', { type: 'date', value: os.estimatedCompletion ?? '', required: false })}</div>
      ${textarea('Observações para o cliente', 'observations', os.observations)}<div class="actions"><button class="btn btn-secondary">Salvar diagnóstico</button></div></form>`)}
    ${card('Adicionar itens', html`<div class="grid grid-2">
      <form data-form="add-service" data-id="${os.id}" class="stack">${select('Serviço', 'serviceId', [['', 'Selecione'], ...s.services.filter(x => x.active !== false).map(x => [x.id, `${x.name} — ${money(x.price)}`])])}<button class="btn btn-secondary">Adicionar serviço</button></form>
      <form data-form="add-part" data-id="${os.id}" class="stack">${select('Peça', 'partId', [['', 'Selecione'], ...s.parts.filter(x => x.active !== false).map(x => [x.id, `${x.name} — ${money(x.price)} (${x.quantity} un.)`])])}
        ${field('Quantidade', 'quantity', { type: 'number', value: 1, attrs: 'min=1 step=1' })}<button class="btn btn-secondary">Adicionar peça</button></form></div>
      ${orderItems(os, { onRemove: true })}
      <p class="muted">Salve o diagnóstico antes de enviar. Depois de enviado, os itens não mudam.</p>
      <div class="actions">${button('Enviar orçamento ao cliente', 'send-quote', { cls: 'btn btn-accent', id: os.id })}</div>`)}`;
  return html`${card('Próximo passo', html`${hint ? html`<p class="muted">${hint}</p>` : ''}${buttons.length ? html`<div class="row wrap">${buttons}</div>` : hint ? '' : html`<p class="muted">Nenhuma ação pendente.</p>`}`)}${evaluation}`;
}

function orderPage(user, orderId) {
  const s = app.state;
  const os = byId(s.workOrders, orderId);
  const base = `/${user.role}/orders`;
  const visible = os && (user.role === 'admin' || (user.role === 'client' ? os.clientId : os.mechanicId) === user.id);
  if (!visible) return page({ title: 'OS não encontrada', body: empty('OS não encontrada', 'Ela não existe ou não está disponível para você.', link(base, 'Voltar às OS')) });
  const v = byId(s.vehicles, os.vehicleId), client = byId(s.users, os.clientId), mech = byId(s.users, os.mechanicId), q = quoteOf(s, os.id);
  const payment = s.payments.find(p => p.osId === os.id);
  const isClient = user.role === 'client';
  const status = q && quoteState(q);
  const quoteNote = !q ? '' : status === 'approved' ? alert('success', 'Orçamento aprovado pelo cliente.')
    : status === 'rejected' ? alert('danger', 'Orçamento recusado pelo cliente.')
    : status === 'expired' ? alert('info', 'Orçamento expirado. A oficina precisa enviar um novo.')
    : alert('warning', `Aguardando aprovação. Válido até ${dateBR(q.validUntil)}.`);
  return page({
    title: `OS #${os.number}`, crumbs: [ROLES[user.role], 'OS', `#${os.number}`],
    subtitle: `${isClient ? '' : `${client?.name ?? ''} · `}${v?.brand ?? ''} ${v?.model ?? ''} ${v?.year ?? ''}`,
    actions: badge(ORDER_STATUS[os.status]),
    body: html`
      ${card('Progresso da OS', timeline(os.status))}
      ${isClient ? '' : workshopPanel(os, user)}
      <div class="grid grid-2">
        ${card('Veículo', rows([['Veículo', `${v?.brand ?? ''} ${v?.model ?? ''}`], ['Ano', v?.year ?? '—'], ['Placa', v?.plate ?? '—'], ['Quilometragem', km(v?.mileage)], ['Mecânico', mech?.name ?? '—']]))}
        ${isClient ? '' : card('Cliente', rows([['Nome', client?.name ?? '—'], ['Telefone', client?.phone ?? '—'], ['E-mail', client?.email ?? '—']]))}
        ${card('Datas', rows([['Abertura', dateBR(os.openedAt)], ['Previsão', dateBR(os.estimatedCompletion)], ['Conclusão', dateBR(os.completedAt)]]))}
      </div>
      ${card('Problema relatado', html`<p>${os.reportedProblem}</p>${os.diagnosis ? html`<h3>Diagnóstico técnico</h3><p>${os.diagnosis}</p>` : ''}`)}
      ${isClient && os.status === 'in_evaluation' ? alert('info', 'Seu veículo está em avaliação. Assim que o diagnóstico for concluído, você receberá o orçamento.') : ''}
      ${os.status === 'in_evaluation' && !isClient ? '' : card(q ? 'Orçamento' : 'Itens e valores', html`${orderItems(os)}
        ${q?.notes ? alert('info', q.notes) : ''}${quoteNote}
        ${isClient && status === 'pending' && os.status === 'quote_pending' ? quoteButtons(q) : ''}`, q ? badge(QUOTE_STATUS[status]) : '')}
      ${payment ? card('Pagamento', rows([['Valor', money(payment.amount)], ['Forma', PAYMENT_METHODS[payment.method] ?? payment.method], ['Data', dateBR(payment.date)], ['Comprovante', payment.receipt ?? '—']])) : ''}
      <div>${link(base, '← Voltar às OS', 'btn btn-secondary')}</div>`,
  });
}

const run = (fn, message) => ({ id }) => commit((s, u) => fn(s, u, id), message);
Object.assign(actions, {
  'approve-quote': ({ id }) => commit((s, u) => act.decideQuote(s, u, id, true), 'Orçamento aprovado.'),
  'reject-quote': ({ id }) => commit((s, u) => act.decideQuote(s, u, id, false), 'Orçamento recusado.'),
  'start-evaluation': run(act.startEvaluation, 'Avaliação iniciada.'),
  'start-execution': run(act.startExecution, 'Execução iniciada. Estoque atualizado.'),
  'finish-order': run(act.finishOrder, 'Serviço finalizado.'),
  'request-payment': run(act.requestPayment, 'Pagamento solicitado ao cliente.'),
  'deliver-order': run(act.deliverOrder, 'Veículo entregue.'),
  'send-quote': ({ id }) => commit((s, u) => { keepDraft(s, u, id); act.sendQuote(s, u, id); }, 'Orçamento enviado.'),
  reopen: run(act.reopenEvaluation, 'Avaliação reaberta.'),
  'remove-item': ({ id, value }) => { const [kind, i] = value.split(':'); commit((s, u) => { keepDraft(s, u, id); act.removeItem(s, u, id, kind, Number(i)); }); },
  'open-payment': ({ id }) => openDialog('Registrar pagamento', html`<form data-form="payment" data-id="${id}" class="stack">
    <p>Valor: <strong>${money(orderTotals(byId(app.state.workOrders, id)).total)}</strong></p>
    ${select('Forma de pagamento', 'method', [['', 'Selecione'], ...Object.entries(PAYMENT_METHODS)])}${dialogActions('Confirmar pagamento')}</form>`),
  'open-cancel': ({ id }) => openDialog(`Cancelar a OS #${byId(app.state.workOrders, id).number}?`, html`<form data-form="cancel-order" data-id="${id}" class="stack">
    <p>A OS e o agendamento serão encerrados. Esta ação não pode ser desfeita.</p>
    <div class="actions">${button('Manter OS', 'close-dialog', { cls: 'btn btn-secondary' })}<button class="btn btn-danger">Cancelar OS</button></div></form>`),
});

const submit = (fn, message, close) => (values, form) => {
  const { ok } = commit((s, u) => fn(s, u, form.dataset.id, values), message);
  if (ok && close) closeDialog();
};
/* Mantém o diagnóstico digitado ao adicionar itens: salva o rascunho antes de redesenhar. */
function keepDraft(s, u, id) {
  const form = document.querySelector('form[data-form="diagnosis"]');
  if (form) act.saveDiagnosis(s, u, id, Object.fromEntries(new FormData(form)));
}
Object.assign(forms, {
  diagnosis: submit(act.saveDiagnosis, 'Diagnóstico salvo.'),
  'add-service': submit((s, u, id, v) => { keepDraft(s, u, id); act.addService(s, u, id, v.serviceId); }, 'Serviço adicionado.'),
  'add-part': submit((s, u, id, v) => { keepDraft(s, u, id); act.addPart(s, u, id, v.partId, v.quantity); }, 'Peça adicionada.'),
  payment: submit((s, u, id, v) => act.registerPayment(s, u, id, v.method), 'Pagamento registrado.', true),
  'cancel-order': submit((s, u, id) => act.cancelOrder(s, u, id), 'OS cancelada.', true),
});
return { quoteButtons, orderPage };
})();

/* ===== pages/client ===== */
const M_pages_client = (() => {
const { html } = M_ui_html;
const { icon } = M_ui_icons;
const { page, card, stats, empty, alert, badge, button, link, field, select, textarea, rows } = M_ui_components;
const { app, view, actions, forms, commit, currentUser } = M_context;
const act = M_domain_actions;
const { ORDER_STATUS, APPT_STATUS, QUOTE_STATUS, PAYMENT_STATUS, PAYMENT_METHODS, BRANDS, TIMES, CLOSED } = M_domain_constants;
const { byId, quoteOf, quoteState, orderTotals, slotAvailable } = M_domain_queries;
const { openDialog, closeDialog, dialogActions } = M_ui_feedback;
const { quoteButtons } = M_pages_order;
const { money, dateBR, dateTimeBR, km, isoDate, plural } = M_util;
const mine = user => ({
  vehicles: app.state.vehicles.filter(v => v.clientId === user.id),
  orders: app.state.workOrders.filter(o => o.clientId === user.id),
});
const car = v => `${v?.brand ?? ''} ${v?.model ?? ''}`.trim() || 'Veículo';
const crumbs = name => ['Cliente', name];
const unread = user => app.state.notifications.filter(n => n.userId === user.id && !n.read).length;

const vehicleCard = (v, editable) => html`<article class="card">
  <div class="row-between"><span class="tile">${icon('car')}</span><span class="plate">${v.plate}</span></div>
  <h3>${car(v)}</h3><p class="muted">${v.year} · ${v.color || '—'}</p>
  <div class="row-between"><span><small class="muted">Quilometragem</small><br><strong>${km(v.mileage)}</strong></span>
  ${editable ? button('Editar', 'edit-vehicle', { cls: 'btn btn-secondary btn-sm', id: v.id }) : ''}</div></article>`;

const orderRow = o => {
  const v = byId(app.state.vehicles, o.vehicleId);
  return html`<a class="card list-card" href="#/client/orders/${o.id}"><span class="order-number">#${o.number}</span>
    <span class="grow"><strong>${car(v)}</strong><small class="muted">${v?.plate} · Aberta em ${dateBR(o.openedAt)}</small><span>${o.reportedProblem}</span></span>${badge(ORDER_STATUS[o.status])}</a>`;
};

function dashboard(user) {
  const { vehicles, orders } = mine(user);
  const active = orders.find(o => ![...CLOSED, 'paid'].includes(o.status));
  const v = active ? byId(app.state.vehicles, active.vehicleId) : vehicles[0];
  const q = active && quoteOf(app.state, active.id);
  const pending = orders.filter(o => o.status === 'awaiting_payment');
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
  const quick = [['car','Meus veículos','/client/vehicles'],['calendar','Agendar avaliação','/client/appointments/new'],['clipboard','Minhas OS','/client/orders'],['money','Orçamentos','/client/quotes'],['clock','Histórico','/client/history'],['card','Pagamentos','/client/payments'],['bell','Notificações','/client/notifications']];
  const panel = active
    ? card('Serviço em andamento', html`<h3>${car(v)}</h3><p class="muted">OS #${active.number} · ${v?.plate}</p><p>${active.reportedProblem}</p>
        <div class="row-between wrap"><span class="muted">${q ? `Orçamento: ${money(q.total)}` : 'Acompanhe as atualizações da manutenção.'}</span>${link(`/client/orders/${active.id}`, 'Ver detalhes →', '')}</div>
        ${q && quoteState(q) === 'pending' ? alert('warning', html`Seu orçamento está aguardando aprovação. <a href="#/client/quotes">Analisar orçamento</a>`) : ''}`, badge(ORDER_STATUS[active.status]))
    : card('Seu veículo', html`<h3>${v ? car(v) : 'Adicione seu primeiro veículo'}</h3><p class="muted">${v ? `${v.year} · ${v.plate}` : 'Cadastre um veículo para agendar serviços.'}</p>${link(v ? '/client/appointments/new' : '/client/vehicles', v ? 'Agendar avaliação' : 'Cadastrar veículo')}`);
  return page({
    title: `${greeting}, ${user.name.split(' ')[0]}!`, subtitle: 'Confira o status dos seus veículos e serviços.', crumbs: crumbs('Dashboard'),
    body: html`${panel}
      ${stats([['Veículos', vehicles.length], ['Ordens de serviço', orders.length], ['Orçamentos', app.state.quotes.filter(x => orders.some(o => o.id === x.osId)).length], ['Não lidas', unread(user)]])}
      ${pending.length ? alert('warning', html`Você possui ${plural(pending.length, 'pagamento', 'pagamentos')} aguardando. <a href="#/client/payments">Ver pagamentos →</a>`) : ''}
      <div class="row-between"><h2>Meus veículos</h2>${link('/client/vehicles', 'Ver todos →', '')}</div>
      ${vehicles.length ? html`<div class="grid grid-3">${vehicles.map(x => vehicleCard(x, false))}</div>` : empty('Nenhum veículo cadastrado', 'Adicione seu veículo para começar.', link('/client/vehicles', 'Adicionar veículo'))}
      <h2>Acesso rápido</h2><div class="grid grid-4">${quick.map(([i, label, to]) => html`<a class="card quick" href="#${to}">${icon(i)}<span>${label}</span></a>`)}</div>
      <div class="row-between"><h2>Ordens de serviço recentes</h2>${link('/client/orders', 'Ver todas →', '')}</div>
      ${orders.length ? html`<div class="stack">${orders.slice(0, 3).map(orderRow)}</div>` : empty('Nenhuma OS encontrada', 'Quando houver uma ordem de serviço, ela aparecerá aqui.')}`,
  });
}

function vehiclesPage(user) {
  const { vehicles } = mine(user);
  return page({
    title: 'Meus veículos', subtitle: plural(vehicles.length, 'veículo cadastrado', 'veículos cadastrados'), crumbs: crumbs('Veículos'),
    actions: button('Adicionar veículo', 'open-vehicle'),
    body: vehicles.length ? html`<div class="grid grid-3">${vehicles.map(v => vehicleCard(v, true))}</div>` : empty('Nenhum veículo cadastrado', 'Adicione seu veículo para agendar serviços.', button('Adicionar veículo', 'open-vehicle')),
  });
}

function appointmentsPage(user) {
  const list = app.state.appointments.filter(a => a.clientId === user.id).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  return page({
    title: 'Agendamentos', subtitle: plural(list.length, 'agendamento', 'agendamentos'), crumbs: crumbs('Agendamentos'),
    actions: link('/client/appointments/new', 'Novo agendamento'),
    body: list.length ? list.map(a => { const v = byId(app.state.vehicles, a.vehicleId); return html`<article class="card list-card"><span class="tile">${icon('calendar')}</span>
      <span class="grow"><strong>${car(v)}</strong><small class="muted">${dateBR(a.date)} às ${a.time} · ${v?.plate}</small><span>${a.problem}</span></span><span class="end">${badge(APPT_STATUS[a.status])}
      ${act.canCancelAppointment(app.state, a) ? button('Cancelar', 'open-cancel-appt', { cls: 'btn btn-danger btn-sm', id: a.id }) : ''}</span></article>`; })
      : empty('Nenhum agendamento', 'Agende uma avaliação para seu veículo.', link('/client/appointments/new', 'Agendar avaliação')),
  });
}

const STEPS = [['vehicle','Veículo'],['problem','Problema'],['schedule','Horário'],['confirm','Confirmação']];
function newAppointmentPage(user) {
  const d = view.appointment;
  const { vehicles } = mine(user);
  const v = vehicles.find(x => x.id === d.vehicleId);
  const wrap = body => page({ title: d.step === 'success' ? 'Agendamento confirmado' : 'Agendar avaliação', crumbs: ['Cliente', 'Agendamentos', 'Novo'], body });
  if (d.step === 'success') return wrap(empty('Agendamento confirmado!', `${car(v)} — ${dateBR(d.date)} às ${d.time}. A oficina vai avaliar o problema e enviar um orçamento para sua aprovação antes de iniciar qualquer serviço.`,
    html`<div class="row wrap center">${link('/client/appointments', 'Ver agendamentos', 'btn btn-secondary')}${button('Fazer outro agendamento', 'appt-reset', { cls: 'btn btn-secondary' })}${link('/client', 'Ir ao painel')}</div>`));
  const index = STEPS.findIndex(([k]) => k === d.step);
  const nav = (next, ready, label = 'Continuar') => html`<div class="actions">${index ? button('← Voltar', 'appt-prev', { cls: 'btn btn-secondary' }) : ''}${button(label, next, { disabled: !ready })}</div>`;
  let panel;
  if (d.step === 'vehicle') panel = vehicles.length ? html`<h2>Qual veículo você quer levar?</h2>
    ${vehicles.map(x => html`<button type="button" class="card list-card choice" data-action="appt-vehicle" data-id="${x.id}" aria-pressed="${String(d.vehicleId === x.id)}"><span class="tile">${icon('car')}</span><span class="grow"><strong>${car(x)}</strong><small class="muted">${x.year} · ${x.plate}</small></span>${d.vehicleId === x.id ? icon('check') : ''}</button>`)}
    ${nav('appt-next', Boolean(v))}` : empty('Você não tem veículos cadastrados', 'Cadastre um veículo antes de agendar.', link('/client/vehicles', 'Cadastrar veículo'));
  if (d.step === 'problem') panel = html`<h2>O que está acontecendo com seu veículo?</h2><p class="muted">Descreva com suas palavras (mínimo de 10 caracteres). O diagnóstico técnico é do mecânico.</p>
    ${textarea('Descrição do problema', 'problem', d.problem, { placeholder: 'Ex: Meu carro faz um barulho estranho quando freio...' })}${nav('appt-next', d.problem.trim().length >= 10)}`;
  if (d.step === 'schedule') {
    const free = TIMES.filter(t => slotAvailable(app.state, d.date, t));
    panel = html`<h2>Escolha data e horário</h2>${field('Data', 'date', { type: 'date', value: d.date, attrs: html`min="${isoDate()}"` })}
      ${d.date ? html`<div class="times" role="group" aria-label="Horários">${TIMES.map(t => html`<button type="button" class="chip" data-action="appt-time" data-value="${t}" aria-pressed="${String(d.time === t)}" ${free.includes(t) ? '' : 'disabled'}>${t}</button>`)}</div>
      ${free.length ? '' : alert('warning', 'Não há horários livres nesta data. Escolha outra.')}` : ''}
      ${nav('appt-next', free.includes(d.time))}`;
  }
  if (d.step === 'confirm') panel = html`<h2>Confirmar agendamento</h2>${rows([['Veículo', `${car(v)} ${v?.year ?? ''}`], ['Placa', v?.plate], ['Data', dateBR(d.date)], ['Horário', d.time], ['Problema', d.problem]])}${nav('appt-confirm', true, 'Confirmar agendamento')}`;
  return wrap(html`<ol class="wizard">${STEPS.map(([, label], i) => html`<li class="${i < index ? 'done' : i === index ? 'current' : ''}">${label}</li>`)}</ol><div class="card stack narrow">${panel}</div>`);
}

function ordersPage(user) {
  const { orders } = mine(user);
  return page({ title: 'Ordens de serviço', subtitle: `${orders.length} OS`, crumbs: crumbs('OS'), body: orders.length ? orders.map(orderRow) : empty('Nenhuma OS encontrada', 'Quando houver uma ordem de serviço, ela aparecerá aqui.') });
}

function quotesPage(user) {
  const { orders } = mine(user);
  const quotes = app.state.quotes.filter(q => orders.some(o => o.id === q.osId)).reverse();
  return page({
    title: 'Orçamentos', subtitle: plural(quotes.length, 'orçamento', 'orçamentos'), crumbs: crumbs('Orçamentos'),
    body: quotes.length ? quotes.map(q => {
      const os = byId(orders, q.osId), v = byId(app.state.vehicles, os.vehicleId), status = quoteState(q);
      return card(`OS #${os.number} — ${car(v)}`, html`<p class="muted">Emitido em ${dateBR(q.createdAt)} · Válido até ${dateBR(q.validUntil)}</p>
        ${rows([['Serviços', money(q.servicesTotal)], ['Peças', money(q.partsTotal)], ['Mão de obra', money(q.laborCost)], ['Total', html`<strong>${money(q.total)}</strong>`]])}
        ${q.notes ? alert('info', q.notes) : ''}<div class="row-between wrap">${link(`/client/orders/${os.id}`, 'Ver OS detalhada →', '')}
        ${status === 'pending' && os.status === 'quote_pending' ? quoteButtons(q, 'btn-sm') : ''}</div>`, badge(QUOTE_STATUS[status]));
    }) : empty('Nenhum orçamento disponível', 'Quando um orçamento for criado, ele aparecerá aqui.'),
  });
}

function historyPage(user) {
  const { vehicles, orders } = mine(user);
  return page({
    title: 'Histórico', subtitle: 'Histórico completo de manutenções', crumbs: crumbs('Histórico'),
    body: vehicles.length ? vehicles.map(v => { const list = orders.filter(o => o.vehicleId === v.id); return html`<section class="stack"><h2>${car(v)} ${v.year} <small class="muted">${v.plate}</small></h2>
      ${list.length ? list.map(o => { const p = app.state.payments.find(x => x.osId === o.id); return html`<a class="card list-card" href="#/client/orders/${o.id}"><span class="order-number">#${o.number}</span>
        <span class="grow"><strong>${dateBR(o.openedAt)}</strong><span class="muted">${o.services.map(s => s.name).join(', ') || 'Sem serviços lançados'}</span>${p ? html`<small class="muted">Pago via ${PAYMENT_METHODS[p.method] ?? p.method}</small>` : ''}</span>
        <span class="end"><strong>${money(orderTotals(o).total)}</strong>${badge(ORDER_STATUS[o.status])}</span></a>`; }) : html`<div class="card muted">Nenhuma manutenção registrada para este veículo.</div>`}</section>`; })
      : empty('Nenhum veículo cadastrado', 'O histórico aparece depois do primeiro serviço.', link('/client/vehicles', 'Cadastrar veículo')),
  });
}

function paymentsPage(user) {
  const { orders } = mine(user);
  const payments = app.state.payments.filter(p => orders.some(o => o.id === p.osId)).reverse();
  const pending = orders.filter(o => o.status === 'awaiting_payment');
  return page({
    title: 'Pagamentos', subtitle: plural(payments.length, 'pagamento', 'pagamentos'), crumbs: crumbs('Pagamentos'),
    body: html`${pending.length ? html`<h2>Aguardando pagamento</h2>${pending.map(o => card(`OS #${o.number} — ${car(byId(app.state.vehicles, o.vehicleId))}`,
        html`<p class="muted">Serviço concluído em ${dateBR(o.completedAt || o.openedAt)}</p><p class="big">${money(orderTotals(o).total)}</p><p>Pague na oficina com PIX, cartão ou dinheiro. O comprovante aparece aqui após o registro.</p>`))}` : ''}
      <h2>Histórico de pagamentos</h2>
      ${payments.length ? payments.map(p => { const o = byId(orders, p.osId); return html`<article class="card list-card"><span class="tile">${icon('card')}</span>
        <span class="grow"><strong>OS #${o.number}</strong><small class="muted">${car(byId(app.state.vehicles, o.vehicleId))} · ${dateBR(p.date)} · ${PAYMENT_METHODS[p.method] ?? p.method}</small></span>
        <span class="end"><strong>${money(p.amount)}</strong>${badge(PAYMENT_STATUS[p.status])}${p.receipt ? button('Ver comprovante', 'receipt', { cls: 'btn btn-ghost btn-sm', id: p.id }) : ''}</span></article>`; })
        : empty('Nenhum pagamento registrado', 'Seus pagamentos concluídos serão exibidos aqui.')}`,
  });
}

function notificationsPage(user) {
  const list = app.state.notifications.filter(n => n.userId === user.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const fresh = list.filter(n => !n.read), old = list.filter(n => n.read);
  const item = n => html`<article class="card notice ${n.read ? '' : `unread tone-${n.type}`}"><strong>${n.title}</strong><p>${n.message}</p>
    <div class="row-between wrap"><small class="muted">${dateTimeBR(n.createdAt)}</small><span class="row">
    ${n.read ? '' : button('Marcar como lida', 'mark-read', { cls: 'btn btn-ghost btn-sm', id: n.id })}
    ${n.link ? html`<a href="#${n.link.replace(/^\/client\//, `/${user.role}/`)}" data-action="mark-read" data-id="${n.id}">Ver detalhes →</a>` : ''}</span></div></article>`;
  return page({
    title: 'Notificações', subtitle: fresh.length ? plural(fresh.length, 'não lida', 'não lidas') : 'Todas lidas', crumbs: [user.role === 'client' ? 'Cliente' : 'Mecânico', 'Notificações'],
    body: list.length ? html`${fresh.length ? html`<h2>Não lidas</h2>${fresh.map(item)}` : ''}${old.length ? html`<h2>Anteriores</h2>${old.map(item)}` : ''}` : empty('Nenhuma notificação', 'Quando houver atualizações, elas aparecerão aqui.'),
  });
}

const clientRoutes = {
  '': dashboard, vehicles: vehiclesPage, appointments: appointmentsPage, 'appointments/new': newAppointmentPage, orders: ordersPage,
  quotes: quotesPage, history: historyPage, payments: paymentsPage, notifications: notificationsPage,
};

function vehicleDialog(vehicle = {}) {
  const brands = vehicle.brand && !BRANDS.includes(vehicle.brand) ? [...BRANDS, vehicle.brand] : BRANDS;
  openDialog(vehicle.id ? 'Editar veículo' : 'Adicionar veículo', html`<form data-form="vehicle" data-id="${vehicle.id ?? ''}" class="stack">
    <div class="grid grid-2">${field('Placa', 'plate', { value: vehicle.plate ?? '', placeholder: 'ABC-1234' })}${field('Ano', 'year', { type: 'number', value: vehicle.year ?? '' })}</div>
    ${select('Marca', 'brand', [['', 'Selecione a marca'], ...brands.map(b => [b, b])], vehicle.brand ?? '')}${field('Modelo', 'model', { value: vehicle.model ?? '' })}
    <div class="grid grid-2">${field('Quilometragem', 'mileage', { type: 'number', value: vehicle.mileage ?? '', attrs: 'min=0' })}${field('Cor', 'color', { value: vehicle.color ?? '', required: false })}</div>
    ${dialogActions('Salvar veículo')}</form>`);
}
const step = delta => { const i = STEPS.findIndex(([k]) => k === view.appointment.step); view.appointment.step = STEPS[Math.min(Math.max(i + delta, 0), 3)][0]; app.render(); };
const resetAppointment = () => { view.appointment = { step: 'vehicle', vehicleId: '', problem: '', date: '', time: '' }; };

Object.assign(actions, {
  'open-vehicle': () => vehicleDialog(),
  'edit-vehicle': ({ id }) => vehicleDialog(byId(app.state.vehicles, id)),
  'appt-vehicle': ({ id }) => { view.appointment.vehicleId = id; app.render(); },
  'appt-time': ({ value }) => { view.appointment.time = value; app.render(); },
  'appt-next': () => step(1),
  'appt-prev': () => step(-1),
  'appt-reset': () => { resetAppointment(); app.render(); },
  'appt-confirm': () => {
    view.appointment.step = 'success';
    const { ok } = commit((s, u) => act.createAppointment(s, u, view.appointment), 'Agendamento confirmado com sucesso!');
    if (!ok) { view.appointment.step = 'schedule'; view.appointment.time = ''; app.render(); }
  },
  'mark-read': ({ id }, element) => {
    // Em links, grava antes da navegação redesenhar a tela.
    if (act.markRead(app.state, currentUser(), id)) commit(() => {});
    if (element.tagName === 'A') location.hash = element.getAttribute('href').slice(1);
  },
  receipt: ({ id }) => {
    const p = byId(app.state.payments, id), o = byId(app.state.workOrders, p.osId);
    openDialog('Comprovante (demonstração)', html`${rows([['Número', p.receipt], ['OS', `#${o.number}`], ['Data', dateBR(p.date)], ['Forma', PAYMENT_METHODS[p.method] ?? p.method], ['Valor', money(p.amount)]])}
      <p class="muted">Sem valor fiscal.</p><div class="actions">${button('Imprimir', 'print')}</div>`);
  },
  print: () => window.print(),
});
forms.vehicle = (values, form) => {
  const editing = Boolean(form.dataset.id);
  if (commit((s, u) => act.saveVehicle(s, u, values, form.dataset.id), editing ? 'Veículo atualizado com sucesso!' : 'Veículo cadastrado com sucesso!').ok) closeDialog();
};
return { unread, clientRoutes, resetAppointment, notificationsPage };
})();

/* ===== pages/workshop ===== */
const M_pages_workshop = (() => {
const { html } = M_ui_html;
const { page, card, stats, empty, alert, badge, button, link, table, rows, filters, chart, field, select } = M_ui_components;
const { app, view, actions, forms, commit, go, report: showError, persist } = M_context;
const act = M_domain_actions;
const { ORDER_STATUS, APPT_STATUS, DONE, CLOSED } = M_domain_constants;
const { byId, orderTotals, stockStatus, usersByRole, activeMechanics, isActive, report, monthlyRevenue } = M_domain_queries;
const { saveMechanic } = M_auth;
const { openDialog, closeDialog, dialogActions, toast } = M_ui_feedback;
const { money, dateBR, isoDate, plural } = M_util;
/* Páginas do mecânico e do administrador. */

const car = v => `${v?.brand ?? ''} ${v?.model ?? ''}`.trim();
const user_ = id => byId(app.state.users, id);
const vehicle = id => byId(app.state.vehicles, id);
const orderLink = (role, o) => html`<a href="#/${role}/orders/${o.id}">#${o.number}</a>`;

const appointmentActions = (a, role) => {
  const os = app.state.workOrders.find(o => o.appointmentId === a.id);
  if (os) return orderLink(role, os);
  if (['cancelled', 'completed'].includes(a.status)) return '—';
  const mechanics = activeMechanics(app.state);
  return html`<div class="row wrap">
    ${role === 'admin' ? html`<form data-form="assign" data-id="${a.id}" class="row">
      <select name="mechanicId" aria-label="Mecânico" required><option value="">Mecânico…</option>${mechanics.map(m => html`<option value="${m.id}" ${m.id === a.mechanicId ? 'selected' : ''}>${m.name}</option>`)}</select>
      <button class="btn btn-secondary btn-sm">Atribuir</button></form>` : ''}
    ${a.mechanicId ? button('Abrir OS', 'open-order', { cls: 'btn btn-sm', id: a.id }) : ''}
    ${role === 'admin' && act.canCancelAppointment(app.state, a) ? button('Cancelar', 'open-cancel-appt', { cls: 'btn btn-danger btn-sm', id: a.id }) : ''}</div>`;
};
const appointmentTable = (list, role) => table(['Data', 'Cliente', 'Veículo', 'Problema', 'Status', 'OS / ação'], list.map(a => {
  const v = vehicle(a.vehicleId);
  return [`${dateBR(a.date)} ${a.time}`, user_(a.clientId)?.name, `${car(v)} · ${v?.plate}`, html`<span class="clamp">${a.problem}</span>`, badge(APPT_STATUS[a.status]), appointmentActions(a, role)];
}), 'Nenhum agendamento.');
const byDate = (a, b) => (a.date + a.time).localeCompare(b.date + b.time);

const toggle = (kind, item) => button(isActive(item) ? 'Desativar' : 'Reativar', 'toggle-active',
  { cls: `btn btn-sm ${isActive(item) ? 'btn-danger' : 'btn-secondary'}`, id: item.id, value: kind });

/* ---------- Mecânico ---------- */
function mechanicDashboard(user) {
  const mine = app.state.workOrders.filter(o => o.mechanicId === user.id);
  const appts = app.state.appointments.filter(a => a.mechanicId === user.id).sort(byDate);
  const today = appts.filter(a => a.date === isoDate() && a.status !== 'cancelled');
  const others = appts.filter(a => a.date !== isoDate() && ['scheduled', 'confirmed'].includes(a.status));
  return page({
    title: `Olá, ${user.name.split(' ')[0]}!`, subtitle: 'Resumo das suas atividades.', crumbs: ['Mecânico', 'Dashboard'],
    body: html`${stats([['Total de OS', mine.length], ['Em andamento', mine.filter(o => ![...CLOSED, 'paid'].includes(o.status)).length], ['Concluídas', mine.filter(o => DONE.includes(o.status)).length], ['Orçamentos pendentes', mine.filter(o => o.status === 'quote_pending').length]])}
      <h2>Agenda de hoje</h2>${appointmentTable(today, 'mechanic')}
      ${others.length ? html`<h2>Outros agendamentos sem OS</h2>${appointmentTable(others, 'mechanic')}` : ''}
      <div class="row-between"><h2>Ordens de serviço</h2>${link('/mechanic/orders', 'Ver todas →', '')}</div>
      ${table(['OS', 'Cliente', 'Veículo', 'Problema', 'Status'], mine.slice(0, 5).map(o => [orderLink('mechanic', o), user_(o.clientId)?.name, car(vehicle(o.vehicleId)), html`<span class="clamp">${o.reportedProblem}</span>`, badge(ORDER_STATUS[o.status])]), 'Nenhuma OS atribuída.')}`,
  });
}
function mechanicOrders(user) {
  const mine = app.state.workOrders.filter(o => o.mechanicId === user.id);
  return page({
    title: 'Ordens de serviço', subtitle: `${mine.length} OS atribuídas`, crumbs: ['Mecânico', 'OS'],
    body: mine.length ? mine.map(o => { const v = vehicle(o.vehicleId); return html`<a class="card list-card" href="#/mechanic/orders/${o.id}"><span class="order-number">#${o.number}</span>
      <span class="grow"><strong>${user_(o.clientId)?.name}</strong><small class="muted">${car(v)} ${v?.year} · ${v?.plate} · Aberta em ${dateBR(o.openedAt)}</small><span>${o.reportedProblem}</span></span>${badge(ORDER_STATUS[o.status])}</a>`; })
      : empty('Nenhuma OS atribuída', 'Abra uma OS a partir de um agendamento no painel.'),
  });
}

/* ---------- Admin ---------- */
const orderTable = list => table(['OS', 'Cliente', 'Veículo', 'Mecânico', 'Abertura', 'Status', 'Total'], list.map(o => {
  const v = vehicle(o.vehicleId);
  return [orderLink('admin', o), user_(o.clientId)?.name, `${car(v)} ${v?.year}`, user_(o.mechanicId)?.name ?? '—', dateBR(o.openedAt), badge(ORDER_STATUS[o.status]), money(orderTotals(o).total)];
}));

function adminDashboard() {
  const s = app.state;
  const revenue = monthlyRevenue(s);
  const [previous, current] = revenue.slice(-2);
  const change = previous.value ? Math.round(((current.value - previous.value) / previous.value) * 100) : null;
  const unassigned = s.appointments.filter(a => !a.mechanicId && a.status === 'scheduled').length;
  const paid = s.payments.filter(p => p.status === 'paid').reduce((a, p) => a + p.amount, 0);
  return page({
    title: 'Dashboard administrativo', subtitle: 'Visão geral do sistema AutoCore', crumbs: ['Admin', 'Dashboard'],
    body: html`${unassigned ? alert('warning', html`${plural(unassigned, 'agendamento sem', 'agendamentos sem')} mecânico. <a href="#/admin/appointments">Atribuir →</a>`) : ''}
      ${stats([['Clientes', usersByRole(s, 'client').length], ['Veículos', s.vehicles.length], ['OS abertas', s.workOrders.filter(o => !CLOSED.includes(o.status)).length], ['Em execução', s.workOrders.filter(o => o.status === 'in_execution').length], ['Hoje', s.appointments.filter(a => a.date === isoDate() && a.status !== 'cancelled').length], ['Mecânicos', activeMechanics(s).length]])}
      <div class="grid grid-2">
        ${card('Faturamento do mês', html`<p class="big">${money(current.value)}</p><p class="muted">${change === null ? 'Sem base de comparação com o mês anterior' : `${change >= 0 ? '↑' : '↓'} ${Math.abs(change)}% vs mês anterior`} · Total pago: ${money(paid)}</p>${chart(revenue)}`)}
        ${card('Resumo operacional', rows([['OS no sistema', s.workOrders.length], ['Agendamentos', s.appointments.length], ['Orçamentos', s.quotes.length], ['Peças cadastradas', s.parts.length], ['Serviços disponíveis', s.services.length]]))}
      </div>
      <div class="row-between"><h2>Ordens de serviço recentes</h2>${link('/admin/orders', 'Ver todas →', '')}</div>${orderTable(s.workOrders.slice(0, 5))}`,
  });
}

const adminAppointments = () => page({
  title: 'Agendamentos', subtitle: 'Atribua o mecânico e abra a OS.', crumbs: ['Admin', 'Agendamentos'],
  body: appointmentTable([...app.state.appointments].sort((a, b) => byDate(b, a)), 'admin'),
});

function clientResults() {
  const q = view.clientSearch.toLowerCase();
  const list = usersByRole(app.state, 'client').filter(u => [u.name, u.email, u.cpf].some(x => x.toLowerCase().includes(q)));
  return html`<p class="muted">${plural(list.length, 'cliente', 'clientes')}</p>${table(['Cliente', 'CPF', 'Telefone', 'E-mail', 'Veículos', 'OS', 'Cadastro'], list.map(c => [
    html`<strong>${c.name}</strong>`, c.cpf, c.phone, c.email, app.state.vehicles.filter(v => v.clientId === c.id).length, app.state.workOrders.filter(o => o.clientId === c.id).length, dateBR(c.createdAt)]))}`;
}
const search = (label, key, value) => html`<label class="field search"><span>${label}</span><input type="search" data-search="${key}" value="${value}"></label>`;
const adminClients = () => page({ title: 'Clientes', crumbs: ['Admin', 'Clientes'], body: html`${search('Buscar por nome, e-mail ou CPF', 'clientSearch', view.clientSearch)}<div id="results" class="stack">${clientResults()}</div>` });

function adminMechanics() {
  const list = usersByRole(app.state, 'mechanic');
  return page({
    title: 'Mecânicos', subtitle: plural(list.length, 'mecânico cadastrado', 'mecânicos cadastrados'), crumbs: ['Admin', 'Mecânicos'], actions: button('Adicionar mecânico', 'edit-mechanic'),
    body: html`<div class="grid grid-3">${list.map(m => { const orders = app.state.workOrders.filter(o => o.mechanicId === m.id); return card(isActive(m) ? m.name : `${m.name} (desativado)`, html`
      <p class="muted">${m.email}<br>${m.phone}</p><p>${m.specialty || 'Sem especialidade informada'}</p>
      ${rows([['Total de OS', orders.length], ['Em andamento', orders.filter(o => o.status === 'in_execution').length], ['Concluídas', orders.filter(o => DONE.includes(o.status)).length]])}`,
      html`<span class="row">${button('Editar', 'edit-mechanic', { cls: 'btn btn-secondary btn-sm', id: m.id })}${toggle('mechanic', m)}</span>`); })}</div>`,
  });
}

const adminOrders = () => {
  const options = [['all','Todas'],['waiting','Aguardando'],['in_evaluation','Avaliação'],['quote_pending','Orçamento'],['in_execution','Em execução'],['finished','Finalizadas'],['awaiting_payment','Pagamento'],['delivered','Entregues'],['cancelled','Canceladas']];
  const list = app.state.workOrders.filter(o => view.orderFilter === 'all' || o.status === view.orderFilter);
  return page({ title: 'Ordens de serviço', subtitle: `${app.state.workOrders.length} OS no sistema`, crumbs: ['Admin', 'OS'], body: html`${filters('order-filter', view.orderFilter, options)}${orderTable(list)}` });
};

const adminServices = () => page({
  title: 'Serviços', subtitle: plural(app.state.services.length, 'serviço cadastrado', 'serviços cadastrados'), crumbs: ['Admin', 'Serviços'], actions: button('Adicionar serviço', 'edit-service'),
  body: table(['Nome', 'Descrição', 'Preço', 'Ação'], app.state.services.map(s => [html`<strong>${s.name}</strong>${isActive(s) ? '' : badge(['Desativado'])}`, s.description, money(s.price), html`<span class="row">${button('Editar', 'edit-service', { cls: 'btn btn-secondary btn-sm', id: s.id })}${toggle('service', s)}</span>`])),
});

const STOCK = { available: ['Disponível', 'success'], low: ['Estoque baixo', 'warning'], out: ['Sem estoque', 'danger'] };
function partResults() {
  const q = view.partSearch.toLowerCase();
  const list = app.state.parts.filter(p => `${p.name} ${p.code} ${p.manufacturer}`.toLowerCase().includes(q) && (view.partFilter === 'all' || stockStatus(p) === view.partFilter));
  return table(['Peça', 'Código', 'Fabricante', 'Categoria', 'Preço', 'Quantidade', 'Estoque', 'Ação'], list.map(p => [
    html`<strong>${p.name}</strong>`, p.code, p.manufacturer, p.category, money(p.price), p.quantity, badge(isActive(p) ? STOCK[stockStatus(p)] : ['Desativada']),
    html`<span class="row">${button('Ajustar', 'edit-stock', { cls: 'btn btn-secondary btn-sm', id: p.id })}${button('Editar', 'edit-part', { cls: 'btn btn-ghost btn-sm', id: p.id })}${toggle('part', p)}</span>`]));
}
function adminParts() {
  const low = app.state.parts.filter(p => isActive(p) && stockStatus(p) !== 'available');
  return page({
    title: 'Peças & Estoque', subtitle: plural(app.state.parts.length, 'peça cadastrada', 'peças cadastradas'), crumbs: ['Admin', 'Peças'], actions: button('Adicionar peça', 'edit-part'),
    body: html`${low.length ? alert('warning', html`<strong>Atenção ao estoque</strong><ul>${low.map(p => html`<li>${p.name}: ${stockStatus(p) === 'out' ? 'sem estoque' : `${p.quantity} un. (mín: ${p.minStock})`}</li>`)}</ul>`) : ''}
      ${search('Buscar por nome, código ou fabricante', 'partSearch', view.partSearch)}${filters('part-filter', view.partFilter, [['all','Todos'],['available','Disponível'],['low','Baixo'],['out','Sem estoque']])}<div id="results">${partResults()}</div>`,
  });
}

function adminReports() {
  const s = app.state;
  const r = report(s, view.reportPeriod);
  const label = { month: 'Este mês', quarter: 'Este trimestre', year: 'Este ano' }[view.reportPeriod];
  const max = Math.max(...r.topServices.map(x => x[1]), 1);
  return page({
    title: 'Relatórios', subtitle: 'Calculados a partir dos dados cadastrados', crumbs: ['Admin', 'Relatórios'],
    body: html`${filters('report-period', view.reportPeriod, [['month','Este mês'],['quarter','Trimestre'],['year','Ano']])}
      ${stats([['Faturamento', money(r.revenue), label], ['OS finalizadas', r.finished, label], ['OS canceladas', r.cancelled, label], ['Ticket médio', money(r.ticket), 'Por pagamento']])}
      ${card('Faturamento mensal (últimos 6 meses)', chart(monthlyRevenue(s)))}
      <div class="grid grid-2">${card('Serviços mais realizados', r.topServices.length ? html`<ol class="ranking">${r.topServices.map(([name, count]) => html`<li><span>${name}</span><strong>${count}x</strong><progress max="${max}" value="${count}">${count}</progress></li>`)}</ol>` : html`<p class="muted">Sem dados no período.</p>`)}
      ${card('Métricas gerais', rows([['Total de clientes', usersByRole(s, 'client').length], ['Total de veículos', s.vehicles.length], ['OS no sistema', s.workOrders.length], ['Total recebido', money(s.payments.filter(p => p.status === 'paid').reduce((a, p) => a + p.amount, 0))]]))}</div>`,
  });
}

const mechanicRoutes = { '': mechanicDashboard, orders: mechanicOrders };
const adminRoutes = { '': adminDashboard, appointments: adminAppointments, clients: adminClients, mechanics: adminMechanics, orders: adminOrders, services: adminServices, parts: adminParts, reports: adminReports };
const results = { clientSearch: clientResults, partSearch: partResults };

const filter = key => ({ value }) => { view[key] = value; app.render(); };
Object.assign(actions, {
  'toggle-active': ({ id, value }) => {
    const item = byId(app.state[{ service: 'services', part: 'parts', mechanic: 'users' }[value]], id);
    const next = !isActive(item);
    commit((s, u) => act.setActive(s, u, value, id, next), `${item.name}: ${next ? 'reativado' : 'desativado'}.`);
  },
  'open-cancel-appt': ({ id }) => openDialog('Cancelar agendamento?', html`<form data-form="cancel-appt" data-id="${id}" class="stack">
    <p>O horário volta a ficar livre.</p><div class="actions">${button('Manter', 'close-dialog', { cls: 'btn btn-secondary' })}<button class="btn btn-danger">Cancelar agendamento</button></div></form>`),
  'order-filter': filter('orderFilter'), 'part-filter': filter('partFilter'), 'report-period': filter('reportPeriod'),
  'open-order': ({ id }) => {
    const { ok, result } = commit((s, u) => act.openOrder(s, u, id), 'OS aberta.');
    if (ok) go(`/${user_(app.state.currentUserId).role}/orders/${result.id}`);
  },
  'edit-service': ({ id }) => {
    const x = byId(app.state.services, id) ?? {};
    openDialog(x.id ? 'Editar serviço' : 'Adicionar serviço', html`<form data-form="service" data-id="${x.id ?? ''}" class="stack">${field('Nome', 'name', { value: x.name ?? '' })}${field('Descrição', 'description', { value: x.description ?? '', required: false })}${field('Preço (R$)', 'price', { type: 'number', value: x.price ?? '', attrs: 'min=0 step=0.01' })}${dialogActions('Salvar serviço')}</form>`);
  },
  'edit-part': ({ id }) => {
    const x = byId(app.state.parts, id) ?? {};
    const num = (label, name, step = '1') => field(label, name, { type: 'number', value: x[name] ?? '', attrs: `min=0 step=${step}` });
    openDialog(x.id ? 'Editar peça' : 'Adicionar peça', html`<form data-form="part" data-id="${x.id ?? ''}" class="stack">${field('Nome', 'name', { value: x.name ?? '' })}
      <div class="grid grid-2">${field('Código', 'code', { value: x.code ?? '' })}${field('Fabricante', 'manufacturer', { value: x.manufacturer ?? '' })}${field('Categoria', 'category', { value: x.category ?? '' })}${num('Preço (R$)', 'price', '0.01')}${num('Quantidade', 'quantity')}${num('Estoque mínimo', 'minStock')}</div>${dialogActions('Salvar peça')}</form>`);
  },
  'edit-stock': ({ id }) => {
    const p = byId(app.state.parts, id);
    openDialog('Ajustar estoque', html`<p class="muted">${p.name} · ${p.code}</p><form data-form="stock" data-id="${p.id}" class="stack">${field('Quantidade em estoque', 'quantity', { type: 'number', value: p.quantity, attrs: 'min=0 step=1' })}${field('Estoque mínimo', 'minStock', { type: 'number', value: p.minStock, attrs: 'min=0 step=1' })}${dialogActions('Salvar estoque')}</form>`);
  },
  'edit-mechanic': ({ id }) => {
    const m = byId(app.state.users, id) ?? {};
    openDialog(m.id ? 'Editar mecânico' : 'Adicionar mecânico', html`<form data-form="mechanic" data-id="${m.id ?? ''}" class="stack">${field('Nome', 'name', { value: m.name ?? '' })}
      <div class="grid grid-2">${field('CPF', 'cpf', { value: m.cpf ?? '' })}${field('Telefone', 'phone', { type: 'tel', value: m.phone ?? '' })}</div>${field('E-mail', 'email', { type: 'email', value: m.email ?? '' })}${field('Especialidade', 'specialty', { value: m.specialty ?? '', required: false })}
      ${field(m.id ? 'Nova senha provisória (opcional)' : 'Senha provisória', 'password', { type: 'password', required: !m.id, attrs: 'autocomplete=new-password minlength=6' })}<p class="muted">O mecânico terá de trocar essa senha no próximo acesso.</p>${dialogActions('Salvar mecânico')}</form>`);
  },
});

const saveDialog = (fn, message) => (values, form) => { if (commit((s, u) => fn(s, u, values, form.dataset.id), message).ok) closeDialog(); };
Object.assign(forms, {
  'cancel-appt': (values, form) => { if (commit((s, u) => act.cancelAppointment(s, u, form.dataset.id), 'Agendamento cancelado.').ok) closeDialog(); },
  assign: (values, form) => commit((s, u) => act.assignMechanic(s, u, form.dataset.id, values.mechanicId), 'Mecânico atribuído.'),
  service: saveDialog(act.saveService, 'Serviço salvo.'),
  part: saveDialog(act.savePart, 'Peça salva.'),
  stock: saveDialog((s, u, v, id) => act.adjustStock(s, u, id, v), 'Estoque atualizado com sucesso!'),
  async mechanic(values, form) {
    try { await saveMechanic(app.state, byId(app.state.users, app.state.currentUserId), values, form.dataset.id); persist(); closeDialog(); app.render(); toast('Mecânico salvo.'); }
    catch (err) { showError(err); }
  },
});
return { mechanicRoutes, adminRoutes, results };
})();

/* ===== ui/shell ===== */
const M_ui_shell = (() => {
const { html } = M_ui_html;
const { icon } = M_ui_icons;
const { brand, button } = M_ui_components;
const { ROLES } = M_domain_constants;
const MENUS = {
  client: [['Principal', [['', 'home', 'Dashboard'], ['vehicles', 'car', 'Meus veículos'], ['appointments', 'calendar', 'Agendamentos']]],
    ['Serviços', [['orders', 'clipboard', 'Ordens de serviço'], ['quotes', 'money', 'Orçamentos'], ['history', 'clock', 'Histórico'], ['payments', 'card', 'Pagamentos'], ['notifications', 'bell', 'Notificações']]]],
  mechanic: [['Oficina', [['', 'home', 'Dashboard'], ['orders', 'clipboard', 'Ordens de serviço'], ['notifications', 'bell', 'Notificações']]]],
  admin: [['Gestão', [['', 'home', 'Dashboard'], ['appointments', 'calendar', 'Agendamentos'], ['orders', 'clipboard', 'Ordens de serviço'], ['clients', 'users', 'Clientes'], ['mechanics', 'wrench', 'Mecânicos']]],
    ['Cadastros', [['services', 'tag', 'Serviços'], ['parts', 'box', 'Peças & Estoque'], ['reports', 'chart', 'Relatórios']]]],
};

function shell({ user, section, content, unread, open }) {
  const item = ([key, ic, label]) => {
    const active = section === key || (key && section.startsWith(`${key}/`));
    return html`<a href="#/${user.role}${key ? `/${key}` : ''}" ${active ? 'aria-current=page' : ''}>${icon(ic)}<span>${label}</span>${key === 'notifications' && unread ? html`<b class="count">${unread > 9 ? '9+' : unread}</b>` : ''}</a>`;
  };
  return html`<a class="skip" href="#content" data-action="skip">Pular para o conteúdo</a>
    <div class="shell ${open ? 'menu-open' : ''}">
      <header class="topbar">${button(icon('menu'), 'open-sidebar', { cls: 'btn btn-icon btn-ghost', aria: 'Abrir menu' })}${brand}</header>
      <div class="scrim" data-action="close-sidebar"></div>
      <aside class="sidebar"><div class="row-between">${brand}<span class="only-mobile">${button(icon('x'), 'close-sidebar', { cls: 'btn btn-icon btn-ghost', aria: 'Fechar menu' })}</span></div>
        <nav aria-label="Menu principal">${MENUS[user.role].map(([title, items]) => html`<p>${title}</p>${items.map(item)}`)}</nav>
        <div class="user"><div><strong>${user.name}</strong><small>${ROLES[user.role]}</small></div>
          <div class="row">${button(html`${icon('logout')} Sair`, 'logout', { cls: 'btn btn-secondary btn-sm' })}${button(icon('sun'), 'toggle-theme', { cls: 'btn btn-icon btn-ghost', aria: 'Alternar tema claro e escuro' })}</div></div></aside>
      <main id="content">${content}</main>
    </div>`;
}
return { shell };
})();

/* ===== main ===== */
(() => {
const { app, view, actions, forms, currentUser, home, go, persist, resetView, report } = M_context;
const { KEY, load } = M_store;
const { loginPage, registerPage, changePasswordPage } = M_pages_public;
const { clientRoutes, notificationsPage, resetAppointment, unread } = M_pages_client;
const { mechanicRoutes, adminRoutes, results } = M_pages_workshop;
const { orderPage } = M_pages_order;
const { shell } = M_ui_shell;
const { empty, link, page } = M_ui_components;
const { toast, closeDialog, dialog } = M_ui_feedback;
/* Ponto de entrada: rotas por hash, delegação de eventos e tema. */

/* Alternar tema funciona em todas as páginas; o restante só onde existe #app (login.html). */
function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem('autocore_theme', next); } catch { /* preferência não é essencial */ }
}
if (typeof document !== 'undefined') {
  if (document.getElementById('app')) startApp();
  else document.addEventListener('click', event => { if (event.target.closest('[data-action="toggle-theme"]')) toggleTheme(); });
}

function startApp() {
const root = document.getElementById('app');
const ROUTES = { client: clientRoutes, mechanic: { ...mechanicRoutes, notifications: notificationsPage }, admin: adminRoutes };
const PUBLIC = { '/login': loginPage, '/register': registerPage };
const path = () => location.hash.replace(/^#/, '').split('?')[0] || '/';
let lastPath = null;

function render() {
  const user = currentUser();
  const current = path();
  // Com senha provisória, nenhuma outra tela é exibida.
  if (user?.mustChangePassword) {
    root.innerHTML = String(changePasswordPage(user));
    lastPath = null;
    return;
  }
  // A página inicial é um arquivo próprio (index.html).
  if (current === '/') return user ? go(home(user.role)) : go('/login');
  if (PUBLIC[current]) {
    if (user) return go(home(user.role));
    root.innerHTML = String(PUBLIC[current]());
  } else {
    if (!user) return go('/login');
    const [, role, ...rest] = current.split('/');
    if (role !== user.role) return go(home(user.role));
    const section = rest.join('/');
    const route = Object.hasOwn(ROUTES[role], section) ? ROUTES[role][section] : null;
    const content = route ? route(user)
      : rest[0] === 'orders' && rest.length === 2 ? orderPage(user, rest[1])
      : page({ title: 'Página não encontrada', body: empty('Página não encontrada', 'O endereço solicitado não existe.', link(home(role), 'Voltar ao painel')) });
    root.innerHTML = String(shell({ user, section, content, unread: unread(user), open: view.sidebarOpen }));
  }
  if (current !== lastPath) {
    window.scrollTo(0, 0);
    if (lastPath !== null) root.querySelector('h1')?.focus({ preventScroll: true });
    lastPath = current;
  }
}
app.render = render;

Object.assign(actions, {
  'toggle-theme': toggleTheme,
  'open-sidebar': () => { view.sidebarOpen = true; render(); root.querySelector('.sidebar a')?.focus(); },
  'close-sidebar': () => { view.sidebarOpen = false; render(); root.querySelector('[data-action="open-sidebar"]')?.focus(); },
  'close-dialog': () => closeDialog(),
  skip: () => root.querySelector('h1')?.focus(),
  logout: () => { app.state.currentUserId = null; persist(); resetView(); location.href = 'index.html'; },
});

document.addEventListener('click', event => {
  const element = event.target.closest('[data-action]');
  if (!element || element.disabled) return;
  if (element.tagName === 'A') event.preventDefault();
  actions[element.dataset.action]?.(element.dataset, element);
});
document.addEventListener('submit', async event => {
  const form = event.target.closest('form[data-form]');
  if (!form) return;
  event.preventDefault();
  if (form.dataset.busy) return;
  form.dataset.busy = '1';
  try { await forms[form.dataset.form]?.(Object.fromEntries(new FormData(form)), form); }
  catch (err) { report(err); }
  finally { delete form.dataset.busy; }
});
document.addEventListener('input', event => {
  const { target } = event;
  if (target.dataset.search) {
    view[target.dataset.search] = target.value;
    // Redesenha só os resultados: o campo mantém foco, cursor e acentuação.
    document.getElementById('results').innerHTML = String(results[target.dataset.search]());
  } else if (target.name === 'problem') {
    view.appointment.problem = target.value;
    root.querySelector('[data-action="appt-next"]').disabled = target.value.trim().length < 10;
  }
});
document.addEventListener('change', event => {
  if (event.target.name === 'date' && path() === '/client/appointments/new') {
    Object.assign(view.appointment, { date: event.target.value, time: '' });
    render();
  }
});
document.addEventListener('keydown', event => { if (event.key === 'Escape' && view.sidebarOpen) actions['close-sidebar'](); });

window.addEventListener('hashchange', () => {
  closeDialog();
  view.sidebarOpen = false; view.loginError = '';
  if (path() !== '/client/appointments/new' && view.appointment.step === 'success') resetAppointment();
  render();
});
window.addEventListener('storage', event => {
  if (event.key !== KEY) return;
  app.state = load(localStorage).state;
  // Não apaga o que está sendo digitado; a próxima ação já usa os dados novos.
  const typing = dialog().open || document.activeElement?.matches('input, textarea, select');
  if (!typing) render();
});

render();
if (app.warning) toast(app.warning, 'danger');
}
})();

/* Usado pelos testes em docs/tests. */
globalThis.AutoCore = { seed: M_seed, domain_actions: M_domain_actions, domain_queries: M_domain_queries, domain_validation: M_domain_validation, auth: M_auth, store: M_store, util: M_util };
